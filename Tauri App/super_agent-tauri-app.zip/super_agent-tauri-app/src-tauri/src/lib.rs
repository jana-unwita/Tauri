use tauri::Manager;

mod acp;
mod agents;
mod fs_commands;

#[cfg_attr(mobile, tauri::mobile_entry_point)]
pub fn run() {
    tauri::Builder::default()
        .plugin(tauri_plugin_dialog::init())
        .setup(|app| {
            if cfg!(debug_assertions) {
                app.handle().plugin(
                    tauri_plugin_log::Builder::default()
                        .level(log::LevelFilter::Info)
                        .build(),
                )?;
            }
            Ok(())
        })
        .manage(acp::state::AcpState::new())
        .invoke_handler(tauri::generate_handler![
            acp::commands::acp_initialize,
            acp::commands::acp_send_prompt,
            acp::commands::acp_is_active,
            acp::commands::acp_cancel,
            acp::commands::acp_shutdown,
            acp::commands::acp_answer_permission,
            agents::commands::agent_create,
            agents::commands::agent_delete,
            agents::commands::read_agents,
            fs_commands::read_dir_tree,
        ])
        .on_window_event(|window, event| {
            if let tauri::WindowEvent::Destroyed = event {
                let app = window.app_handle().clone();
                let state = app.state::<acp::state::AcpState>();
                let inner_arc = state.inner.clone();
                tauri::async_runtime::spawn(async move {
                    let mut guard = inner_arc.lock().await;
                    for (_, h) in guard.drain() {
                        let _ = h.tx.send(acp::runner::AcpCmd::Shutdown).await;
                    }
                });
            }
        })
        .run(tauri::generate_context!())
        .expect("error while running tauri application");
}
