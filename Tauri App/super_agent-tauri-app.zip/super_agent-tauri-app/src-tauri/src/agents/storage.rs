use std::path::{Path, PathBuf};

/// Parsed representation of a `.claude/agents/*.md` file.
#[derive(serde::Serialize)]
pub struct AgentInfo {
    pub id: String,           // file stem / slug
    pub name: String,
    pub description: String,
    pub model: String,
    pub system_prompt: String,
    pub source: String,       // "project" | "global"
}

/// Parse a `.claude/agents/*.md` file into an `AgentInfo`.
/// Returns `None` if the file is unreadable or should be hidden
/// (coordinator agents: `role: coordinator` or slug `co-ordinator`).
pub fn parse_agent_md(path: &Path, source: &str) -> Option<AgentInfo> {
    let content = std::fs::read_to_string(path).ok()?;
    let slug = path.file_stem()?.to_string_lossy().to_string();

    // Always skip co-ordinator by slug
    if slug == "co-ordinator" {
        return None;
    }

    let mut name = slug.clone();
    let mut description = String::new();
    let mut model = String::new();
    let mut role = String::new();
    let mut system_prompt = String::new();

    // Expect frontmatter: starts with "---\n", ends at next "\n---"
    if let Some(rest) = content.strip_prefix("---\n") {
        if let Some(fm_end) = rest.find("\n---") {
            let frontmatter = &rest[..fm_end];
            let after_fm = &rest[fm_end + 4..]; // skip "\n---"
            system_prompt = after_fm.trim_start_matches('\n').to_string();

            for line in frontmatter.lines() {
                if let Some((k, v)) = line.split_once(": ") {
                    let v = v.trim().trim_matches('"').to_string();
                    match k.trim() {
                        "name"        => name = v,
                        "description" => description = v,
                        "model"       => model = v,
                        "role"        => role = v,
                        _ => {}
                    }
                }
            }
        }
    }

    // Skip coordinator role
    if role == "coordinator" {
        return None;
    }

    Some(AgentInfo { id: slug, name, description, model, system_prompt, source: source.to_string() })
}

/// Returns the agents directory for the given project, creating it if needed.
/// Path: `<project_path>/.claude/agents/`
pub fn agents_dir(project_path: &str) -> Result<PathBuf, String> {
    let dir = PathBuf::from(project_path).join(".claude").join("agents");
    if !dir.exists() {
        std::fs::create_dir_all(&dir)
            .map_err(|e| format!("Failed to create agents dir: {}", e))?;
    }
    Ok(dir)
}

/// Convert an agent name to a filename-safe slug.
/// e.g. "My Weather Agent" → "my-weather-agent"
pub fn name_to_slug(name: &str) -> String {
    let mut slug = String::new();
    let mut last_was_dash = false;
    for ch in name.chars() {
        if ch.is_alphanumeric() {
            slug.push(ch.to_ascii_lowercase());
            last_was_dash = false;
        } else if !last_was_dash && !slug.is_empty() {
            slug.push('-');
            last_was_dash = true;
        }
    }
    // Trim trailing dash
    slug.trim_end_matches('-').to_string()
}

/// Build the markdown content for a Claude Code agent definition file.
///
/// Format:
/// ```
/// ---
/// name: <name>
/// description: <description>
/// model: <model>
/// ---
///
/// <system_prompt>
/// ```
pub fn build_agent_md(
    name: &str,
    description: &str,
    model: &str,
    system_prompt: &str,
) -> String {
    let mut lines: Vec<String> = Vec::new();

    lines.push("---".to_string());
    lines.push(format!("name: {}", name));
    if !description.is_empty() {
        lines.push(format!("description: {}", description));
    }
    if !model.is_empty() {
        lines.push(format!("model: {}", model));
    }
    lines.push("---".to_string());

    if !system_prompt.is_empty() {
        lines.push(String::new());
        lines.push(system_prompt.trim().to_string());
    }

    lines.join("\n")
}

/// Write an agent .md file under `<project_path>/.claude/agents/<slug>.md`.
/// Returns the slug used as the file stem (also the agent's ID).
pub fn write_agent(
    project_path: &str,
    name: &str,
    description: &str,
    model: &str,
    system_prompt: &str,
) -> Result<String, String> {
    let slug = name_to_slug(name);
    if slug.is_empty() {
        return Err("Agent name produces an empty slug".to_string());
    }

    let dir = agents_dir(project_path)?;
    let path = dir.join(format!("{}.md", slug));

    let content = build_agent_md(name, description, model, system_prompt);
    std::fs::write(&path, content)
        .map_err(|e| format!("Failed to write agent file: {}", e))?;

    Ok(slug)
}
