use super::storage;

fn read_agents_from_dir(
    dir: &std::path::Path,
    source: &str,
    seen: &mut std::collections::HashSet<String>,
    agents: &mut Vec<storage::AgentInfo>,
) {
    if let Ok(entries) = std::fs::read_dir(dir) {
        for entry in entries.flatten() {
            let path = entry.path();
            if path.extension().map_or(false, |e| e == "md") {
                let key = path.to_string_lossy().to_string();
                if seen.insert(key) {
                    if let Some(info) = storage::parse_agent_md(&path, source) {
                        agents.push(info);
                    }
                }
            }
        }
    }
}

/// Read agents from three sources (deduplicated by absolute path):
/// 1. App predefined: `<CWD>/.claude/agents/` — always included
/// 2. Project-level: `<project_path>/.claude/agents/` — when a project is open
/// 3. Global: `~/.claude/agents/`
/// Co-ordinator / coordinator-role agents are automatically excluded.
#[tauri::command]
pub fn read_agents(project_path: String) -> Vec<storage::AgentInfo> {
    let mut seen = std::collections::HashSet::new();
    let mut agents = Vec::new();

    // 1. App predefined agents — compile-time path is always correct
    {
        let predefined_dir = std::path::Path::new(env!("CARGO_MANIFEST_DIR"))
            .parent()
            .expect("CARGO_MANIFEST_DIR has no parent")
            .join(".claude")
            .join("agents");
        read_agents_from_dir(&predefined_dir, "predefined", &mut seen, &mut agents);
    }

    // 2. Project-level agents (skip if empty)
    if !project_path.is_empty() {
        let proj_dir = std::path::PathBuf::from(&project_path)
            .join(".claude")
            .join("agents");
        read_agents_from_dir(&proj_dir, "project", &mut seen, &mut agents);
    }

    // 3. Global agents (~/.claude/agents/)
    if let Ok(home) = std::env::var("HOME") {
        let global_dir = std::path::PathBuf::from(home).join(".claude").join("agents");
        read_agents_from_dir(&global_dir, "global", &mut seen, &mut agents);
    }

    agents
}

#[tauri::command]
pub fn agent_delete(id: String, source: String, project_path: String) -> Result<(), String> {
    let path = match source.as_str() {
        "project" => std::path::PathBuf::from(&project_path)
            .join(".claude")
            .join("agents")
            .join(format!("{}.md", id)),
        "global" => {
            let home = std::env::var("HOME").map_err(|_| "HOME not set".to_string())?;
            std::path::PathBuf::from(home)
                .join(".claude")
                .join("agents")
                .join(format!("{}.md", id))
        }
        _ => return Err(format!("Cannot delete agent with source '{}'", source)),
    };
    if path.exists() {
        std::fs::remove_file(&path)
            .map_err(|e| format!("Failed to delete agent file: {}", e))?;
    }
    Ok(())
}

#[tauri::command]
pub async fn agent_create(
    name: String,
    description: Option<String>,
    model: String,
    system_prompt: Option<String>,
    project_path: String,
) -> Result<serde_json::Value, String> {
    let slug = storage::write_agent(
        &project_path,
        &name,
        description.as_deref().unwrap_or(""),
        &model,
        system_prompt.as_deref().unwrap_or(""),
    )?;

    Ok(serde_json::json!({
        "id": slug,
        "name": name,
    }))
}
