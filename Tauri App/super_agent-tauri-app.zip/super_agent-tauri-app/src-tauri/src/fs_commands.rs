use serde::Serialize;

const SKIP_DIRS: &[&str] = &[
    "node_modules",
    ".git",
    "target",
    "dist",
    "build",
    ".next",
    ".nuxt",
    "__pycache__",
    ".venv",
    "venv",
    ".yarn",
    ".pnp",
    "coverage",
    ".turbo",
];

#[derive(Serialize)]
pub struct FileEntry {
    pub name: String,
    #[serde(rename = "type")]
    pub entry_type: String,
    #[serde(skip_serializing_if = "Option::is_none")]
    pub children: Option<Vec<FileEntry>>,
}

#[tauri::command]
pub fn read_dir_tree(path: String) -> Result<Vec<FileEntry>, String> {
    read_recursive(&path)
}

fn read_recursive(path: &str) -> Result<Vec<FileEntry>, String> {
    let entries: Vec<_> = std::fs::read_dir(path)
        .map_err(|e| format!("Cannot read {}: {}", path, e))?
        .filter_map(|e| e.ok())
        .collect();

    let mut nodes: Vec<FileEntry> = entries
        .into_iter()
        .filter_map(|entry| {
            let name = entry.file_name().to_string_lossy().to_string();
            let ft = entry.file_type().ok()?;
            if ft.is_dir() {
                let children = if SKIP_DIRS.contains(&name.as_str()) {
                    Some(vec![])
                } else {
                    let child_path = format!("{}/{}", path, name);
                    Some(read_recursive(&child_path).unwrap_or_default())
                };
                Some(FileEntry {
                    name,
                    entry_type: "folder".into(),
                    children,
                })
            } else {
                Some(FileEntry {
                    name,
                    entry_type: "file".into(),
                    children: None,
                })
            }
        })
        .collect();

    // folders first, then alphabetical within each group
    nodes.sort_by(|a, b| match (a.entry_type.as_str(), b.entry_type.as_str()) {
        ("folder", "file") => std::cmp::Ordering::Less,
        ("file", "folder") => std::cmp::Ordering::Greater,
        _ => a.name.cmp(&b.name),
    });

    Ok(nodes)
}
