use serde::Serialize;
use tauri::{AppHandle, Emitter};
use tokio::sync::oneshot;

use super::state::PermissionPending;

#[derive(Clone, Serialize)]
#[serde(rename_all = "camelCase")]
pub struct ChatChunkEvent {
    pub session_key: String,
    pub text: String,
    pub done: bool,
}

#[derive(Clone, Serialize)]
#[serde(rename_all = "camelCase")]
pub struct ToolCallEvent {
    pub session_key: String,
    pub title: String,
}

#[derive(Clone, Serialize)]
#[serde(rename_all = "camelCase")]
pub struct PermissionRequestEvent {
    pub session_key: String,
    pub options: Vec<String>,
}

/// Implements the ACP `Client` trait for the Tauri desktop app.
///
/// - `session_notification` → extracts text chunks → emits `acp:message-chunk` events
///                            and tool calls → emits `acp:tool-call` events
/// - `request_permission` → shows permission UI, waits for user response
pub struct TauriAcpClient {
    pub app: AppHandle,
    pub session_key: String,
    pub permission_pending: PermissionPending,
}

#[async_trait::async_trait(?Send)]
impl agent_client_protocol::Client for TauriAcpClient {
    async fn session_notification(
        &self,
        args: agent_client_protocol::SessionNotification,
    ) -> agent_client_protocol::Result<()> {
        use agent_client_protocol::{ContentBlock, SessionUpdate};

        match args.update {
            SessionUpdate::AgentMessageChunk(chunk) => {
                let text = match chunk.content {
                    ContentBlock::Text(t) => t.text,
                    _ => return Ok(()),
                };
                if !text.is_empty() {
                    let _ = self.app.emit(
                        "acp:message-chunk",
                        ChatChunkEvent {
                            session_key: self.session_key.clone(),
                            text,
                            done: false,
                        },
                    );
                }
            }
            SessionUpdate::ToolCall(tc) => {
                let _ = self.app.emit(
                    "acp:tool-call",
                    ToolCallEvent {
                        session_key: self.session_key.clone(),
                        title: tc.title.clone(),
                    },
                );
            }
            _ => {}
        }
        Ok(())
    }

    async fn request_permission(
        &self,
        args: agent_client_protocol::RequestPermissionRequest,
    ) -> agent_client_protocol::Result<agent_client_protocol::RequestPermissionResponse> {
        use agent_client_protocol::{RequestPermissionOutcome, SelectedPermissionOutcome};

        // Build human-readable option labels based on position heuristic
        let n = args.options.len();
        let option_labels: Vec<String> = (0..n)
            .map(|i| {
                if n <= 1 {
                    "Allow".to_string()
                } else if i == n - 1 {
                    "Deny".to_string()
                } else if n == 2 && i == 0 {
                    "Allow".to_string()
                } else if n >= 3 && i == 0 {
                    "Allow once".to_string()
                } else if n >= 3 && i == 1 {
                    "Allow always".to_string()
                } else {
                    format!("Option {}", i + 1)
                }
            })
            .collect();

        // Emit permission request event to UI
        let _ = self.app.emit(
            "acp:permission-request",
            PermissionRequestEvent {
                session_key: self.session_key.clone(),
                options: option_labels,
            },
        );

        // Register a oneshot channel waiting for the user's choice
        let (tx, rx) = oneshot::channel::<usize>();
        {
            let mut pending = self.permission_pending.lock().await;
            pending.insert(self.session_key.clone(), tx);
        }

        // Wait up to 5 minutes for user response, then fall back to first option
        let chosen_idx = match tokio::time::timeout(std::time::Duration::from_secs(300), rx).await
        {
            Ok(Ok(idx)) => idx,
            _ => 0,
        };

        // Clean up pending entry
        {
            let mut pending = self.permission_pending.lock().await;
            pending.remove(&self.session_key);
        }

        let outcome = args
            .options
            .into_iter()
            .nth(chosen_idx)
            .map(|o| {
                RequestPermissionOutcome::Selected(SelectedPermissionOutcome::new(o.option_id))
            })
            .unwrap_or(RequestPermissionOutcome::Cancelled);

        Ok(agent_client_protocol::RequestPermissionResponse::new(
            outcome,
        ))
    }
}
