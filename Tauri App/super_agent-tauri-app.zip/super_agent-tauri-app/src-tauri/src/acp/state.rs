use std::collections::HashMap;
use std::sync::Arc;
use tokio::sync::{mpsc, oneshot, Mutex};

use super::runner::AcpCmd;

/// Shared map of pending permission requests.
/// Key = session_key, value = oneshot sender for the chosen option index.
pub type PermissionPending = Arc<Mutex<HashMap<String, oneshot::Sender<usize>>>>;

/// Tauri managed state — holds all active ACP session handles keyed by session_key.
/// The "default" key is used when the caller omits session_key.
pub struct AcpState {
    pub inner: Arc<Mutex<HashMap<String, AcpHandle>>>,
    pub permission_pending: PermissionPending,
}

impl AcpState {
    pub fn new() -> Self {
        Self {
            inner: Arc::new(Mutex::new(HashMap::new())),
            permission_pending: Arc::new(Mutex::new(HashMap::new())),
        }
    }
}

/// Handle to one ACP runner thread — the only `Send`-safe bridge to the
/// `!Send` `ClientSideConnection` living on the dedicated runner thread.
pub struct AcpHandle {
    /// Channel sender to the ACP runner thread.
    pub tx: mpsc::Sender<AcpCmd>,
    /// Session ID returned by `session/new` during initialization.
    pub session_id: String,
}
