use std::path::PathBuf;
use std::process::Stdio;

use agent_client_protocol::{
    Agent, ClientSideConnection, ContentBlock, Implementation, InitializeRequest,
    NewSessionRequest, PromptRequest, ProtocolVersion,
};
use tauri::{AppHandle, Emitter};
use tokio::io::{AsyncBufReadExt, AsyncWriteExt, BufReader};
use tokio::process::Command;
use tokio::sync::{mpsc, oneshot};
use tokio_util::compat::{TokioAsyncReadCompatExt, TokioAsyncWriteCompatExt};

use super::client::{ChatChunkEvent, TauriAcpClient};
use super::state::PermissionPending;

/// Commands sent from Tauri command handlers (multi-threaded runtime) to the
/// single-threaded ACP runner (LocalSet). The channel itself is `Send`; the
/// `ClientSideConnection` inside the runner is not.
pub enum AcpCmd {
    SendPrompt {
        session_id: String,
        message: String,
        resp: oneshot::Sender<Result<(), String>>,
    },
    Cancel {
        session_id: String,
    },
    Shutdown,
}

/// Write `{cwd}/.claude/settings.local.json` with broad tool permissions.
/// Only written when the file does not already exist.
fn ensure_settings(cwd: &str) {
    let claude_dir = PathBuf::from(cwd).join(".claude");
    let settings_path = claude_dir.join("settings.local.json");
    if !settings_path.exists() {
        let settings = serde_json::json!({
            "permissions": {
                "allow": [
                    "Bash(*)", "Write(*)", "Edit(*)",
                    "Read(*)", "Glob(*)", "Grep(*)", "MultiEdit(*)"
                ]
            }
        });
        if let Ok(json) = serde_json::to_string_pretty(&settings) {
            let _ = std::fs::create_dir_all(&claude_dir);
            let _ = std::fs::write(&settings_path, json);
        }
    }
}

/// Spawn a dedicated OS thread with its own single-threaded Tokio runtime + LocalSet.
/// The `ClientSideConnection` (`!Send`) lives entirely inside this thread.
///
/// `session_key` is forwarded to event payloads so the frontend can route chunks
/// to the correct UI component.
pub async fn spawn_acp_runner(
    app: AppHandle,
    cwd: String,
    model: Option<String>,
    session_key: String,
    permission_pending: PermissionPending,
) -> Result<(mpsc::Sender<AcpCmd>, String), String> {
    let (tx, rx) = mpsc::channel::<AcpCmd>(32);
    let (init_tx, init_rx) = oneshot::channel::<Result<String, String>>();

    std::thread::spawn(move || {
        let rt = tokio::runtime::Builder::new_current_thread()
            .enable_all()
            .build()
            .expect("Failed to build single-thread Tokio runtime for ACP");

        let local = tokio::task::LocalSet::new();
        local.block_on(&rt, async move {
            match init_acp(
                app.clone(),
                &cwd,
                model,
                session_key.clone(),
                permission_pending,
            )
            .await
            {
                Err(e) => {
                    let _ = init_tx.send(Err(e));
                }
                Ok((conn, session_id)) => {
                    let _ = init_tx.send(Ok(session_id));
                    run_loop(conn, rx, app, session_key).await;
                }
            }
        });
    });

    match init_rx.await {
        Ok(Ok(session_id)) => Ok((tx, session_id)),
        Ok(Err(e)) => Err(e),
        Err(_) => Err("ACP runner thread exited before init".to_string()),
    }
}

/// Initialize: write settings, spawn subprocess, create ClientSideConnection,
/// run ACP handshake. Returns connection + session_id.
async fn init_acp(
    app: AppHandle,
    cwd: &str,
    model: Option<String>,
    session_key: String,
    permission_pending: PermissionPending,
) -> Result<(ClientSideConnection, String), String> {
    ensure_settings(cwd);

    let mut cmd = Command::new("npx");
    cmd.arg("claude-code-acp")
        .current_dir(cwd)
        .env("CLAUDE_ALLOWED_TOOLS", "Write,Edit,Bash,Read,Glob,Grep,MultiEdit")
        .stdin(Stdio::piped())
        .stdout(Stdio::piped())
        .stderr(Stdio::inherit());

    if let Some(m) = model.as_deref().filter(|s| !s.trim().is_empty()) {
        cmd.env("ANTHROPIC_MODEL", m);
    }

    let mut child = cmd
        .spawn()
        .map_err(|e| format!("Failed to start claude-code-acp: {}", e))?;

    let stdin = child.stdin.take().ok_or("Failed to capture agent stdin")?;
    let stdout = child.stdout.take().ok_or("Failed to capture agent stdout")?;

    // Filter claude-code-acp's stdout: only forward lines starting with '{'
    // (compact JSON-RPC messages). Drop [ACP] debug lines and pretty-printed
    // JSON fragments — they cause harmless but noisy parse errors in the crate.
    let (mut pipe_writer, pipe_reader) = tokio::io::duplex(65536);
    tokio::task::spawn_local(async move {
        let mut lines = BufReader::new(stdout).lines();
        while let Ok(Some(line)) = lines.next_line().await {
            if line.starts_with('{') {
                let _ = pipe_writer.write_all(line.as_bytes()).await;
                let _ = pipe_writer.write_all(b"\n").await;
            }
        }
    });

    let app_clone = app.clone();
    let session_key_clone = session_key.clone();

    let (conn, handle_io) = ClientSideConnection::new(
        TauriAcpClient {
            app: app.clone(),
            session_key: session_key.clone(),
            permission_pending,
        },
        stdin.compat_write(),
        pipe_reader.compat(),
        |fut| {
            tokio::task::spawn_local(fut);
        },
    );

    tokio::task::spawn_local(async move {
        if let Err(e) = handle_io.await {
            eprintln!("[ACP] I/O loop ended: {}", e);
        }
        let _ = app_clone.emit("acp:disconnected", session_key_clone);
        drop(child);
    });

    conn.initialize(
        InitializeRequest::new(ProtocolVersion::V1)
            .client_info(Implementation::new("super-agent", "0.1.0")),
    )
    .await
    .map_err(|e| format!("ACP initialize failed: {}", e))?;

    let session_resp = conn
        .new_session(NewSessionRequest::new(PathBuf::from(cwd)))
        .await
        .map_err(|e| format!("ACP new_session failed: {}", e))?;

    let session_id = session_resp.session_id.to_string();

    Ok((conn, session_id))
}

/// Process AcpCmd messages from Tauri command handlers.
async fn run_loop(
    conn: ClientSideConnection,
    mut rx: mpsc::Receiver<AcpCmd>,
    app: AppHandle,
    session_key: String,
) {
    while let Some(cmd) = rx.recv().await {
        match cmd {
            AcpCmd::SendPrompt {
                session_id: sid,
                message,
                resp,
            } => {
                let result = conn
                    .prompt(PromptRequest::new(sid, vec![ContentBlock::from(message)]))
                    .await
                    .map(|_| ())
                    .map_err(|e| e.to_string());

                // Signal end-of-turn to the frontend
                let _ = app.emit(
                    "acp:message-chunk",
                    ChatChunkEvent {
                        session_key: session_key.clone(),
                        text: String::new(),
                        done: true,
                    },
                );

                let _ = resp.send(result);
            }
            AcpCmd::Cancel { session_id: sid } => {
                use agent_client_protocol::CancelNotification;
                let _ = conn.cancel(CancelNotification::new(sid)).await;
            }
            AcpCmd::Shutdown => {
                break;
            }
        }
    }
}
