use tauri::{AppHandle, State};
use tokio::sync::oneshot;

use super::runner::{spawn_acp_runner, AcpCmd};
use super::state::{AcpHandle, AcpState};

/// Resolve the session key, defaulting to "default" so existing callers
/// that omit `session_key` continue to work unchanged.
fn resolve_key(session_key: Option<String>) -> String {
    session_key
        .filter(|s| !s.trim().is_empty())
        .unwrap_or_else(|| "default".to_string())
}

#[tauri::command]
pub async fn acp_initialize(
    session_key: Option<String>,
    model: Option<String>,
    cwd: Option<String>,
    state: State<'_, AcpState>,
    app: AppHandle,
) -> Result<(), String> {
    let key = resolve_key(session_key);

    {
        let guard = state.inner.lock().await;
        if let Some(h) = guard.get(&key) {
            if !h.tx.is_closed() {
                return Ok(()); // session already active
            }
        }
    }

    let resolved_cwd = cwd
        .as_deref()
        .filter(|s| !s.trim().is_empty())
        .map(|s| s.to_string())
        .unwrap_or_else(|| {
            std::env::var("HOME")
                .or_else(|_| std::env::var("USERPROFILE"))
                .unwrap_or_else(|_| "/tmp".to_string())
        });

    let (tx, session_id) = spawn_acp_runner(
        app,
        resolved_cwd,
        model,
        key.clone(),
        state.permission_pending.clone(),
    )
    .await?;

    let mut guard = state.inner.lock().await;
    guard.insert(key, AcpHandle { tx, session_id });
    Ok(())
}

#[tauri::command]
pub async fn acp_send_prompt(
    session_key: Option<String>,
    message: String,
    state: State<'_, AcpState>,
) -> Result<(), String> {
    let key = resolve_key(session_key);

    let (tx, session_id) = {
        let guard = state.inner.lock().await;
        let h = guard.get(&key).ok_or("ACP not initialized")?;
        (h.tx.clone(), h.session_id.clone())
    };

    let (resp_tx, resp_rx) = oneshot::channel();
    tx.send(AcpCmd::SendPrompt {
        session_id,
        message,
        resp: resp_tx,
    })
    .await
    .map_err(|_| "ACP runner channel closed".to_string())?;

    resp_rx
        .await
        .map_err(|_| "ACP runner dropped response channel".to_string())?
}

#[tauri::command]
pub async fn acp_is_active(
    session_key: Option<String>,
    state: State<'_, AcpState>,
) -> Result<bool, String> {
    let key = resolve_key(session_key);
    let guard = state.inner.lock().await;
    Ok(guard.get(&key).map_or(false, |h| !h.tx.is_closed()))
}

#[tauri::command]
pub async fn acp_cancel(
    session_key: Option<String>,
    state: State<'_, AcpState>,
) -> Result<(), String> {
    let key = resolve_key(session_key);
    let guard = state.inner.lock().await;
    if let Some(h) = guard.get(&key) {
        let _ = h
            .tx
            .send(AcpCmd::Cancel {
                session_id: h.session_id.clone(),
            })
            .await;
    }
    Ok(())
}

#[tauri::command]
pub async fn acp_shutdown(
    session_key: Option<String>,
    state: State<'_, AcpState>,
) -> Result<(), String> {
    let key = resolve_key(session_key);
    let mut guard = state.inner.lock().await;
    if let Some(h) = guard.remove(&key) {
        let _ = h.tx.send(AcpCmd::Shutdown).await;
    }
    Ok(())
}

/// Answer a pending permission request for a given session.
/// `option_index` is the 0-based index into the options array shown in the UI.
#[tauri::command]
pub async fn acp_answer_permission(
    session_key: String,
    option_index: usize,
    state: State<'_, AcpState>,
) -> Result<(), String> {
    let mut pending = state.permission_pending.lock().await;
    if let Some(tx) = pending.remove(&session_key) {
        let _ = tx.send(option_index);
    }
    Ok(())
}
