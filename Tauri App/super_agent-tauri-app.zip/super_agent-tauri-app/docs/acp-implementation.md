# ACP Implementation

## Overview
This app connects to AI coding agents via the **Agent Client Protocol (ACP)** — a JSON-RPC protocol over stdio, similar to LSP. Each agent terminal maps to one ACP session.

Reference: https://agentclientprotocol.com

## Architecture

```
Frontend (React)          Rust (Tauri)              ACP Agent
─────────────────         ─────────────             ──────────
AgentTerminal             acp::commands             npx claude-code-acp
  invoke(acp_initialize)  → spawn_acp_runner()      ← JSON-RPC stdio
  invoke(acp_send_prompt) → conn.prompt()           ← PromptRequest
  listen(acp:message-chunk) ← conn.session_notification → text chunks
  listen(acp:tool-call)   ← SessionUpdate::ToolCall  → tool use
  listen(acp:permission-request) ← request_permission → tool approval
```

## ACP Session Lifecycle

1. **Initialize** — `acp_initialize(sessionKey, cwd, model)`
   - Spawns `npx claude-code-acp` subprocess
   - Runs ACP handshake (`conn.initialize`)
   - Creates session (`conn.new_session`)
   - Writes `.claude/settings.local.json` with tool permissions

2. **Send Prompt** — `acp_send_prompt(sessionKey, message)`
   - Sends `PromptRequest` to the ACP session
   - Response streams back via `acp:message-chunk` events

3. **Cancel** — `acp_cancel(sessionKey)`
   - Sends `CancelNotification` to stop current generation

4. **Shutdown** — `acp_shutdown(sessionKey)`
   - Closes the session and kills the subprocess

## Events (Rust → Frontend)

| Event | Payload | When |
|-------|---------|------|
| `acp:message-chunk` | `{ sessionKey, text, done }` | Text streaming from agent |
| `acp:tool-call` | `{ sessionKey, title }` | Agent is using a tool |
| `acp:permission-request` | `{ sessionKey, options }` | Agent needs tool approval |
| `acp:disconnected` | `sessionKey` | ACP subprocess exited |

## Agent Storage

Agents are saved as markdown files with YAML frontmatter:

**Path:** `<project_root>/.claude/agents/<slug>.md`

**Format:**
```
---
name: Security Auditor
description: Reviews code for security vulnerabilities
model: claude-sonnet-4-6
---

You are a security auditor. Review code for...
```

All agents are **project-level** (stored in the project folder). Global agent scope is deferred.

## Tauri Commands

| Command | Parameters | Description |
|---------|-----------|-------------|
| `acp_initialize` | sessionKey, cwd, model | Start ACP session |
| `acp_send_prompt` | sessionKey, message | Send message to agent |
| `acp_is_active` | sessionKey | Check if session running |
| `acp_cancel` | sessionKey | Cancel current generation |
| `acp_shutdown` | sessionKey | Close session |
| `acp_answer_permission` | sessionKey, optionIndex | Respond to tool permission |
| `agent_create` | name, description, model, systemPrompt, projectPath | Create & save agent |

## Session Key
Each `AgentTerminal` uses `agent.id` as its `sessionKey`, so events are routed to the correct terminal.
