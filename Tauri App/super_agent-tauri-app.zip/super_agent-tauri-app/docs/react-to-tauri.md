# React to Tauri: Best Practices Guide

A practical guide for converting a React + Vite app into a Tauri desktop application.
Tailored for this project: **React 18 + Vite 5 + TypeScript + Tailwind CSS**.

---

## 1. Prerequisites

### System Requirements

**All platforms:**
- [Rust](https://www.rust-lang.org/tools/install) (stable toolchain via `rustup`)
- Node.js 18+

**macOS:**
```bash
xcode-select --install
```

**Linux (Debian/Ubuntu):**
```bash
sudo apt install libwebkit2gtk-4.1-dev libssl-dev libgtk-3-dev \
  libayatana-appindicator3-dev librsvg2-dev
```

**Windows:**
- Microsoft Visual Studio C++ Build Tools
- WebView2 (pre-installed on Windows 11; download for Windows 10)

---

## 2. Adding Tauri to an Existing Vite + React Project

### Install Tauri CLI and API

```bash
npm add -D @tauri-apps/cli@latest
npm add @tauri-apps/api@latest
```

### Initialize Tauri

```bash
npx tauri init
```

Prompts to answer for this project:
| Prompt | Value |
|---|---|
| App name | `super-agent` |
| Window title | `Super Agent Desktop App` |
| Web assets location | `../dist` |
| Dev server URL | `http://localhost:5000` |
| Frontend dev command | `npm run dev` |
| Frontend build command | `npm run build` |

This generates the `src-tauri/` directory:

```
src-tauri/
├── Cargo.toml          # Rust dependencies
├── build.rs            # Tauri build script
├── icons/              # App icons (replace with your own)
└── src/
    └── main.rs         # Rust entry point
└── tauri.conf.json     # Main Tauri configuration
```

---

## 3. Vite Config Changes

Update `vite.config.ts` so Vite works well alongside Tauri:

```ts
// vite.config.ts
import { defineConfig } from 'vite'
import react from '@vitejs/plugin-react'

export default defineConfig({
  plugins: [react()],

  // Prevent Vite from obscuring Rust error messages
  clearScreen: false,

  server: {
    port: 5000,
    strictPort: true,   // Fail if port is taken (Tauri expects a fixed port)
    watch: {
      // Watch src-tauri for rebuild triggers
      ignored: ['**/src-tauri/**'],
    },
  },

  build: {
    // Tauri supports ES2021+ on all supported OS versions
    target: ['es2021', 'chrome105', 'safari13'],
    minify: !process.env.TAURI_DEBUG ? 'esbuild' : false,
    sourcemap: !!process.env.TAURI_DEBUG,
  },
})
```

---

## 4. package.json Scripts

Add these scripts:

```json
{
  "scripts": {
    "dev": "vite",
    "build": "tsc && vite build",
    "tauri": "tauri",
    "tauri dev": "tauri dev",
    "tauri build": "tauri build"
  }
}
```

**Development:** `npm run tauri dev` — starts Vite dev server and Tauri window together.
**Production:** `npm run tauri build` — compiles Rust, bundles frontend, produces installer.

---

## 5. Project-Specific Notes

This project's stack is fully compatible with Tauri out of the box:

| Technology | Tauri Compatibility |
|---|---|
| React 18 | Full support |
| Vite 5 | Official recommendation |
| TypeScript 5 | Full support |
| Tailwind CSS 3 | Full support (pure CSS, no issues) |
| Framer Motion | Full support |
| Emotion | Full support |

No changes needed to existing component code.

---

## 6. Using Tauri APIs (Replacing Browser APIs)

Install the Tauri API package (already done in step 2). Use Tauri's JS APIs instead of browser equivalents for native features.

### Filesystem

```ts
import { readTextFile, writeTextFile, BaseDirectory } from '@tauri-apps/api/fs'

// Read a file from the app's data directory
const content = await readTextFile('config.json', { dir: BaseDirectory.AppData })

// Write a file
await writeTextFile('output.txt', data, { dir: BaseDirectory.Document })
```

### Shell / Running Commands

```ts
import { Command } from '@tauri-apps/api/shell'

const output = await Command.create('run-my-script', ['--arg']).execute()
console.log(output.stdout)
```

### Native Dialogs

```ts
import { open, save } from '@tauri-apps/api/dialog'

const filePath = await open({ filters: [{ name: 'JSON', extensions: ['json'] }] })
const savePath = await save({ defaultPath: 'output.json' })
```

### Notifications

```ts
import { sendNotification } from '@tauri-apps/api/notification'

sendNotification({ title: 'Done', body: 'Task completed.' })
```

### Conditional Logic (Web vs Desktop)

Use `__TAURI__` to run code only in the desktop context:

```ts
const isTauri = typeof window.__TAURI__ !== 'undefined'

if (isTauri) {
  const { appWindow } = await import('@tauri-apps/api/window')
  await appWindow.setTitle('Custom Title')
}
```

For TypeScript to recognize `window.__TAURI__`, add this to a `.d.ts` file:

```ts
// src/tauri.d.ts
declare global {
  interface Window {
    __TAURI__?: unknown
  }
}
export {}
```

---

## 7. Security Best Practices

### allowlist in `tauri.conf.json`

Only enable the Tauri APIs your app actually uses. Default is everything disabled.

```json
{
  "tauri": {
    "allowlist": {
      "all": false,
      "shell": {
        "all": false,
        "open": true      // Allow opening URLs in the browser
      },
      "dialog": {
        "all": true
      },
      "fs": {
        "all": false,
        "readFile": true,
        "writeFile": true,
        "scope": ["$APPDATA/*", "$DOCUMENT/*"]  // Restrict to specific dirs
      }
    }
  }
}
```

### Content Security Policy

Set a strict CSP in `tauri.conf.json`:

```json
{
  "tauri": {
    "security": {
      "csp": "default-src 'self'; script-src 'self'; style-src 'self' 'unsafe-inline'"
    }
  }
}
```

### IPC Best Practices

- Validate all data passed from the frontend to Rust commands
- Never expose sensitive system operations without authentication
- Prefer specific Tauri API calls over `shell.execute` with arbitrary commands

---

## 8. Native Window Customization

Configure the window appearance in `src-tauri/tauri.conf.json`:

```json
{
  "tauri": {
    "windows": [
      {
        "title": "Super Agent Desktop App",
        "width": 1280,
        "height": 800,
        "minWidth": 900,
        "minHeight": 600,
        "resizable": true,
        "fullscreen": false,
        "decorations": true,       // Set false for custom title bar
        "transparent": false,
        "center": true
      }
    ]
  }
}
```

For a **custom title bar** (frameless window), set `"decorations": false` and implement drag behavior in CSS:

```css
/* Make a region draggable as window title bar */
.titlebar {
  -webkit-app-region: drag;
  app-region: drag;
}

/* Buttons inside draggable region must opt-out */
.titlebar button {
  -webkit-app-region: no-drag;
  app-region: no-drag;
}
```

---

## 9. Building & Distributing

### Development Build

```bash
npm run tauri dev
```

### Production Build

```bash
npm run tauri build
```

Output is in `src-tauri/target/release/bundle/`:
- **macOS**: `.dmg` and `.app`
- **Windows**: `.msi` and `.exe` (NSIS)
- **Linux**: `.deb`, `.rpm`, `.AppImage`

### Code Signing

**macOS:** Set `APPLE_CERTIFICATE`, `APPLE_CERTIFICATE_PASSWORD`, `APPLE_ID`, `APPLE_PASSWORD` env vars and configure `tauri.conf.json`:
```json
{ "tauri": { "macOS": { "signingIdentity": "Developer ID Application: ..." } } }
```

**Windows:** Configure `tauri.conf.json` with your certificate path and password.

### Auto-Updater

Add the updater plugin for in-app updates:
```bash
npm add @tauri-apps/plugin-updater
```
Configure `tauri.conf.json` with your update endpoint URL and signing keys.

---

## 10. Common Pitfalls

### CORS in Tauri
Tauri uses `tauri://localhost` as the origin. External APIs that block this origin will fail. Solutions:
- Use a Rust command as a proxy for API calls
- Configure the target server to allow `tauri://localhost`

### Absolute File Paths
Never hardcode system paths. Always use Tauri's `BaseDirectory` enum:
```ts
// Bad
readTextFile('/Users/john/AppData/config.json')

// Good
readTextFile('config.json', { dir: BaseDirectory.AppData })
```

### `localStorage` / `sessionStorage`
These work in Tauri but data is stored in WebView storage — it resets on reinstall. For persistent app data, use `@tauri-apps/api/fs` with `BaseDirectory.AppData`.

### Node.js APIs are Unavailable
The frontend runs in a WebView, not Node.js. You cannot use `fs`, `path`, `child_process`, etc. directly. Write Rust commands instead and invoke them via IPC.

### Hot Reload
`tauri dev` supports HMR for the frontend (via Vite). Rust code changes require a Rust recompile — this takes longer. Keep your Rust backend lean and stable.

---

## Quick Start Checklist

- [ ] Install Rust (`rustup`) and system dependencies
- [ ] `npm add -D @tauri-apps/cli@latest && npm add @tauri-apps/api@latest`
- [ ] `npx tauri init` with correct paths
- [ ] Update `vite.config.ts` (clearScreen, strictPort, build.target)
- [ ] Add `tauri dev` and `tauri build` scripts to `package.json`
- [ ] Configure allowlist in `tauri.conf.json` (only what you need)
- [ ] Add `src/tauri.d.ts` for TypeScript type safety
- [ ] Test with `npm run tauri dev`
- [ ] Run `npm run tauri build` for a production installer
