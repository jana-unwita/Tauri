import React, { useEffect, useState, useRef } from 'react';
import { motion } from 'framer-motion';
import { SendHorizontalIcon } from 'lucide-react';
import { invoke } from '@tauri-apps/api/core';
import { listen } from '@tauri-apps/api/event';
import { Agent } from '../data/mockData';

interface AgentTerminalProps {
  agent: Agent;
  cwd?: string;
}

function StatusBadge({ status }: { status: Agent['status'] | 'running' | 'done' | 'idle' }) {
  const config: Record<string, { label: string; color: string; dotClass: string }> = {
    running: {
      label: 'Running',
      color: 'bg-teal-600',
      dotClass: 'pulse-dot',
    },
    waiting: {
      label: 'Waiting',
      color: 'bg-amber-500',
      dotClass: '',
    },
    done: {
      label: 'Done',
      color: 'bg-emerald-600',
      dotClass: '',
    },
    idle: {
      label: 'Idle',
      color: 'bg-zinc-400',
      dotClass: '',
    },
  };
  const c = config[status] ?? config['idle'];
  return (
    <span className="flex items-center gap-1.5 text-xs font-medium text-zinc-500">
      <span className={`w-2 h-2 rounded-full ${c.color} ${c.dotClass}`} />
      {c.label}
    </span>
  );
}

function TokenBar({ used, limit }: { used: number; limit: number }) {
  const pct = limit > 0 ? Math.round((used / limit) * 100) : 0;
  const blocks = 10;
  const filled = Math.round((pct / 100) * blocks);
  return (
    <div className="flex items-center gap-2 px-3 py-1.5 border-b border-zinc-100 font-mono text-[11px] text-zinc-400">
      <div className="flex gap-[2px]">
        {Array.from({ length: blocks }).map((_, i) => (
          <div
            key={i}
            className={`w-[6px] h-[10px] rounded-[1px] ${i < filled ? 'bg-teal-500' : 'bg-zinc-200'}`}
          />
        ))}
      </div>
      <span>
        {used >= 1000 ? `${Math.round(used / 1000)}k` : used} /{' '}
        {Math.round(limit / 1000)}k · {pct}%
      </span>
    </div>
  );
}

export function AgentTerminal({ agent, cwd }: AgentTerminalProps) {
  const [inputValue, setInputValue] = useState('');
  const streamRef = useRef<HTMLDivElement>(null);
  const [visibleLines, setVisibleLines] = useState<string[]>([]);

  // ACP state
  const [acpReady, setAcpReady] = useState(false);
  const [acpStatus, setAcpStatus] = useState<'idle' | 'running' | 'done'>('idle');
  const [streamLines, setStreamLines] = useState<string[]>([]);
  const [permissionRequest, setPermissionRequest] = useState<{ options: string[] } | null>(null);
  const [currentTool, setCurrentTool] = useState<string>('');

  // Mock live stream effect (only when ACP is not active)
  useEffect(() => {
    if (agent.status === 'running' && agent.liveStream.length > 0) {
      setVisibleLines([]);
      const timers: ReturnType<typeof setTimeout>[] = [];
      agent.liveStream.forEach((line, i) => {
        const t = setTimeout(() => {
          setVisibleLines((prev) => [...prev, line]);
        }, i * 600);
        timers.push(t);
      });
      return () => timers.forEach(clearTimeout);
    } else {
      setVisibleLines(agent.liveStream);
    }
  }, [agent.id, agent.status]);

  // Auto-scroll
  useEffect(() => {
    if (streamRef.current) {
      streamRef.current.scrollTop = streamRef.current.scrollHeight;
    }
  }, [visibleLines, streamLines]);

  // ACP event listeners
  useEffect(() => {
    const unlisteners: (() => void)[] = [];

    // Stream chunks
    listen<{ sessionKey: string; text: string; done: boolean }>(
      'acp:message-chunk',
      (e) => {
        if (e.payload.sessionKey !== agent.id) return;
        if (e.payload.done) {
          setAcpStatus('done');
          setCurrentTool('');
        } else if (e.payload.text) {
          setStreamLines((prev) => {
            const lines = [...prev];
            const lastLine = lines[lines.length - 1] || '';
            if (e.payload.text.includes('\n')) {
              const parts = (lastLine + e.payload.text).split('\n');
              return [...prev.slice(0, -1), ...parts].filter(
                (_, i, arr) => i < arr.length - 1 || arr[i] !== ''
              );
            }
            if (lines.length === 0) return [e.payload.text];
            lines[lines.length - 1] = lastLine + e.payload.text;
            return lines;
          });
        }
      }
    ).then((fn) => unlisteners.push(fn));

    // Tool calls
    listen<{ sessionKey: string; title: string }>('acp:tool-call', (e) => {
      if (e.payload.sessionKey !== agent.id) return;
      setCurrentTool(e.payload.title);
    }).then((fn) => unlisteners.push(fn));

    // Permission requests
    listen<{ sessionKey: string; options: string[] }>('acp:permission-request', (e) => {
      if (e.payload.sessionKey !== agent.id) return;
      setPermissionRequest({ options: e.payload.options });
    }).then((fn) => unlisteners.push(fn));

    // Disconnected
    listen<string>('acp:disconnected', (e) => {
      if (e.payload !== agent.id) return;
      setAcpReady(false);
      setAcpStatus('idle');
    }).then((fn) => unlisteners.push(fn));

    return () => {
      unlisteners.forEach((fn) => fn());
      // Shutdown ACP session on unmount
      invoke('acp_shutdown', { sessionKey: agent.id }).catch(() => {});
    };
  }, [agent.id]);

  async function handleSend() {
    if (!inputValue.trim()) return;
    const message = inputValue.trim();
    setInputValue('');

    try {
      // Initialize ACP session if not ready
      if (!acpReady) {
        await invoke('acp_initialize', {
          sessionKey: agent.id,
          cwd: cwd || '',
          model: agent.model,
        });
        setAcpReady(true);
        setAcpStatus('running');
      }

      // Send prompt (non-blocking - response comes via events)
      invoke('acp_send_prompt', {
        sessionKey: agent.id,
        message,
      }).catch(console.error);

      setAcpStatus('running');
    } catch (err) {
      console.error('ACP error:', err);
    }
  }

  async function handlePermission(optionIndex: number) {
    await invoke('acp_answer_permission', { sessionKey: agent.id, optionIndex });
    setPermissionRequest(null);
  }

  // Derived display values
  const displayStatus: Agent['status'] | 'idle' = acpReady
    ? acpStatus === 'running'
      ? 'running'
      : acpStatus === 'done'
      ? 'done'
      : 'idle'
    : agent.status;

  const displayLines = acpReady ? streamLines : visibleLines;
  const displayCurrentAction = acpReady && currentTool ? currentTool : agent.currentAction;
  const isActive = displayStatus === 'running';

  return (
    <motion.div
      initial={{ opacity: 0, y: 12 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.3 }}
      className={`flex flex-col bg-white border rounded-lg overflow-hidden ${
        isActive ? 'border-teal-200 shadow-sm shadow-teal-500/5' : 'border-zinc-200'
      }`}
    >
      {/* Header */}
      <div className="flex items-center justify-between px-3 py-2.5 border-b border-zinc-100">
        <div className="flex items-center gap-2">
          <span className="text-base leading-none">{agent.emoji}</span>
          <span className="text-sm font-semibold text-zinc-900">{agent.name}</span>
        </div>
        <StatusBadge status={displayStatus} />
      </div>

      {/* Token bar */}
      <TokenBar used={agent.tokenUsed} limit={agent.tokenLimit} />

      {/* Live stream */}
      <div className="px-3 py-2 border-b border-zinc-100">
        <div className="flex items-center gap-2 mb-2">
          <span className="text-[10px] font-semibold uppercase tracking-wider text-zinc-400">
            Live Stream
          </span>
          {displayCurrentAction && isActive && (
            <span className="text-[10px] font-medium text-teal-600">{displayCurrentAction}</span>
          )}
        </div>
        <div
          ref={streamRef}
          className="h-[120px] overflow-y-auto font-mono text-[12px] leading-[1.6] text-zinc-600"
        >
          {displayLines.length === 0 ? (
            <span className="text-zinc-300 italic">(no activity yet)</span>
          ) : (
            displayLines.map((line, i) => (
              <div key={i} className="flex">
                <span className="text-zinc-300 mr-2 select-none shrink-0">&gt;</span>
                <span>
                  {line}
                  {isActive && i === displayLines.length - 1 && (
                    <span className="cursor-blink text-teal-500 ml-0.5">▌</span>
                  )}
                </span>
              </div>
            ))
          )}
        </div>
      </div>

      {/* Footer */}
      <div className="flex items-center justify-between px-3 py-1.5 border-b border-zinc-100 text-[11px] text-zinc-400">
        <span className="font-mono">⏱ {agent.elapsed}</span>
        <span className="font-medium">{agent.model}</span>
      </div>

      {/* Permission request bar */}
      {permissionRequest && (
        <div className="px-3 py-2 bg-amber-50 border-b border-amber-100 text-[12px]">
          <span className="text-amber-700 font-medium mr-2">Tool permission requested:</span>
          {permissionRequest.options.map((opt, i) => (
            <button
              key={i}
              onClick={() => handlePermission(i)}
              className="mr-2 px-2 py-0.5 rounded text-xs font-medium bg-white border border-amber-200 text-amber-800 hover:bg-amber-100"
            >
              {opt}
            </button>
          ))}
        </div>
      )}

      {/* Input */}
      <div className="flex items-center gap-2 px-3 py-2">
        <input
          type="text"
          value={inputValue}
          onChange={(e) => setInputValue(e.target.value)}
          placeholder={`Ask ${agent.name.replace(' Agent', '')} directly...`}
          className="flex-1 text-[13px] text-zinc-700 placeholder:text-zinc-300 bg-transparent outline-none"
          onKeyDown={(e) => {
            if (e.key === 'Enter') {
              handleSend();
            }
          }}
        />
        <button
          onClick={handleSend}
          className="w-7 h-7 flex items-center justify-center rounded-md text-zinc-300 hover:text-teal-600 hover:bg-teal-50 transition-colors duration-100"
          aria-label="Send message"
        >
          <SendHorizontalIcon className="w-3.5 h-3.5" />
        </button>
      </div>
    </motion.div>
  );
}
