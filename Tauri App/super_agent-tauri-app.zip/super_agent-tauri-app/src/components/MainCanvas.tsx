import React from 'react';
import { AnimatePresence } from 'framer-motion';
import { AgentTerminal } from './AgentTerminal';
import { ActivitiesPanel } from './ActivitiesPanel';
import { FileTreePanel } from './FileTreePanel';
import { TopNavBar } from './TopNavBar';
import { DiffView } from './DiffView';
import { AutoAcceptToggle } from './AutoAcceptToggle';
import { Agent, ActivityEntry, FileNode, DiffFile } from '../data/mockData';
interface MainCanvasProps {
  agents: Agent[];
  activities: ActivityEntry[];
  files: FileNode[];
  diffs: DiffFile[];
  fileTreeOpen: boolean;
  diffOpen: boolean;
  autoAccept: boolean;
  folderName: string;
  cwd: string;
  onOpenFolder: () => void;
  onRefreshFiles: () => void;
  onToggleFileTree: () => void;
  onOpenAgents: () => void;
  onOpenSettings: () => void;
  onToggleDiff: () => void;
  onToggleAutoAccept: () => void;
}
export function MainCanvas({
  agents,
  activities,
  files,
  diffs,
  fileTreeOpen,
  diffOpen,
  autoAccept,
  folderName,
  cwd,
  onOpenFolder,
  onRefreshFiles,
  onToggleFileTree,
  onOpenAgents,
  onOpenSettings,
  onToggleDiff,
  onToggleAutoAccept
}: MainCanvasProps) {
  return (
    <div className="flex flex-col h-screen bg-zinc-50">
      {!diffOpen && <TopNavBar
        onToggleFileTree={onToggleFileTree}
        onOpenAgents={onOpenAgents}
        onOpenSettings={onOpenSettings}
        onOpenDiff={onToggleDiff}
        fileTreeOpen={fileTreeOpen} />}
      

      <div className="flex flex-1 overflow-hidden relative">
        {/* File tree */}
        <FileTreePanel
          open={fileTreeOpen}
          files={files}
          folderPath={folderName}
          onOpenFolder={onOpenFolder}
          onRefresh={onRefreshFiles} />
        

        {/* Agent grid */}
        <main className="flex-1 overflow-y-auto">
          {/* Auto-accept bar */}
          <div className="flex items-center justify-end px-5 py-2 border-b border-zinc-100 bg-white">
            <AutoAcceptToggle
              enabled={autoAccept}
              onToggle={onToggleAutoAccept} />
            
          </div>

          <div className="p-5">
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
              {agents.filter((a) => a.visible !== false).map((agent) =>
              <AgentTerminal key={agent.id} agent={agent} cwd={cwd} />
              )}
            </div>
          </div>
        </main>

        {/* Activities panel */}
        <ActivitiesPanel activities={activities} />

        {/* Diff overlay */}
        <AnimatePresence>
          {diffOpen && (
            <DiffView
              diffs={diffs}
              onClose={onToggleDiff}
              files={files}
              folderPath={folderName}
              onOpenFolder={onOpenFolder}
            />
          )}
        </AnimatePresence>
      </div>
    </div>);

}