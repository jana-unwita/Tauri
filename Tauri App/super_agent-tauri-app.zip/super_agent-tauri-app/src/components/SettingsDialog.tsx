import React, { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { XIcon } from 'lucide-react';
import { LLMEntry } from '../data/mockData';
interface SettingsDialogProps {
  open: boolean;
  onClose: () => void;
  llms: LLMEntry[];
}
export function SettingsDialog({ open, onClose, llms }: SettingsDialogProps) {
  const [orchestratorModel, setOrchestratorModel] =
  useState(llms[1]?.name ?? llms[0]?.name ?? '');
  const [maxAgents, setMaxAgents] = useState('10');
  const [tokenBudget, setTokenBudget] = useState('100000');
  return (
    <AnimatePresence>
      {open &&
      <motion.div
        initial={{
          opacity: 0
        }}
        animate={{
          opacity: 1
        }}
        exit={{
          opacity: 0
        }}
        transition={{
          duration: 0.15
        }}
        className="fixed inset-0 z-50 flex items-center justify-center bg-black/30"
        onClick={onClose}>
        
          <motion.div
          initial={{
            opacity: 0,
            scale: 0.97,
            y: 8
          }}
          animate={{
            opacity: 1,
            scale: 1,
            y: 0
          }}
          exit={{
            opacity: 0,
            scale: 0.97,
            y: 8
          }}
          transition={{
            duration: 0.2
          }}
          onClick={(e) => e.stopPropagation()}
          className="w-[480px] max-h-[85vh] bg-white rounded-xl shadow-xl border border-zinc-200 flex flex-col overflow-hidden">
          
            {/* Header */}
            <div className="flex items-center justify-between px-5 py-4 border-b border-zinc-100">
              <div>
                <h2 className="text-sm font-semibold text-zinc-900">
                  Settings
                </h2>
                <p className="text-[12px] text-zinc-400 mt-0.5">
                  Configure your LLM agents and preferences
                </p>
              </div>
              <button
              onClick={onClose}
              className="w-7 h-7 flex items-center justify-center rounded-md text-zinc-400 hover:text-zinc-600 hover:bg-zinc-100 transition-colors"
              aria-label="Close settings">
              
                <XIcon className="w-4 h-4" />
              </button>
            </div>

            <div className="flex-1 overflow-y-auto px-5 py-4 space-y-5">
              {/* LLMs */}
              <section>
                <h3 className="text-[11px] font-semibold uppercase tracking-wider text-zinc-400 mb-2">
                  LLMs
                </h3>
                <div className="border border-zinc-200 rounded-lg overflow-hidden">
                  {llms.map((llm, i) =>
                <div
                  key={llm.id}
                  className={`flex items-center justify-between px-3 py-2.5 ${i < llms.length - 1 ? 'border-b border-zinc-100' : ''}`}>

                      <div>
                        <span className="text-[13px] font-medium text-zinc-700">{llm.label}</span>
                        <p className="text-[11px] text-zinc-400 mt-0.5">{llm.description}</p>
                        <span className="text-[10px] font-mono text-zinc-300">{llm.name}</span>
                      </div>
                      <span className="flex items-center gap-1.5 text-[11px] font-medium text-zinc-400">
                        <span
                      className={`w-2 h-2 rounded-full ${llm.status === 'running' ? 'bg-teal-500 pulse-dot' : 'bg-zinc-300'}`} />

                        {llm.status}
                      </span>
                    </div>
                )}
                </div>
              </section>

              {/* Defaults */}
              <section>
                <h3 className="text-[11px] font-semibold uppercase tracking-wider text-zinc-400 mb-2">
                  Defaults
                </h3>
                <div className="space-y-3">
                  <div>
                    <label className="text-[12px] font-medium text-zinc-600 mb-1 block">
                      Orchestrator Model
                    </label>
                    <select
                    value={orchestratorModel}
                    onChange={(e) => setOrchestratorModel(e.target.value)}
                    className="w-full px-3 py-2 text-[13px] border border-zinc-200 rounded-lg bg-white text-zinc-700 focus:outline-none focus:ring-2 focus:ring-teal-400 focus:border-transparent">
                    
                      {llms.map((l) =>
                    <option key={l.id} value={l.name}>
                          {l.label} — {l.description}
                        </option>
                    )}
                    </select>
                  </div>
                  <div>
                    <label className="text-[12px] font-medium text-zinc-600 mb-1 block">
                      Max Agents
                    </label>
                    <input
                    type="number"
                    value={maxAgents}
                    onChange={(e) => setMaxAgents(e.target.value)}
                    className="w-full px-3 py-2 text-[13px] font-mono border border-zinc-200 rounded-lg text-zinc-700 focus:outline-none focus:ring-2 focus:ring-teal-400 focus:border-transparent" />
                  
                  </div>
                  <div>
                    <label className="text-[12px] font-medium text-zinc-600 mb-1 block">
                      Token Budget
                    </label>
                    <input
                    type="number"
                    value={tokenBudget}
                    onChange={(e) => setTokenBudget(e.target.value)}
                    className="w-full px-3 py-2 text-[13px] font-mono border border-zinc-200 rounded-lg text-zinc-700 focus:outline-none focus:ring-2 focus:ring-teal-400 focus:border-transparent" />
                  
                  </div>
                </div>
              </section>

              {/* Appearance */}
              <section>
                <h3 className="text-[11px] font-semibold uppercase tracking-wider text-zinc-400 mb-2">
                  Appearance
                </h3>
                <div className="flex items-center justify-between py-2">
                  <span className="text-[13px] text-zinc-600">Dark Mode</span>
                  <div className="flex items-center gap-2">
                    <span className="text-[10px] text-zinc-300 italic">
                      coming soon
                    </span>
                    <div className="w-9 h-5 rounded-full bg-zinc-200 relative opacity-40 cursor-not-allowed">
                      <span className="absolute top-0.5 left-0.5 w-4 h-4 bg-white rounded-full shadow-sm" />
                    </div>
                  </div>
                </div>
              </section>
            </div>

            {/* Footer */}
            <div className="px-5 py-3 border-t border-zinc-100 flex justify-end">
              <button
              onClick={onClose}
              className="px-4 py-2 text-[13px] font-medium bg-zinc-900 text-white rounded-lg hover:bg-zinc-800 active:bg-zinc-950 transition-colors focus:outline-none focus:ring-2 focus:ring-teal-400 focus:ring-offset-2">
              
                Save Settings
              </button>
            </div>
          </motion.div>
        </motion.div>
      }
    </AnimatePresence>);

}