import React, { useEffect, useState, useRef } from 'react';
import { ActivityEntry } from '../data/mockData';
interface ActivitiesPanelProps {
  activities: ActivityEntry[];
}
const filterTabs = [
{
  key: 'all',
  label: 'All'
},
{
  key: 'coordinator',
  label: 'Coordinator'
},
{
  key: 'architect',
  label: 'Architect'
},
{
  key: 'developer',
  label: 'Developer'
},
{
  key: 'reviewer',
  label: 'QA'
}];

export function ActivitiesPanel({ activities }: ActivitiesPanelProps) {
  const [activeFilter, setActiveFilter] = useState('all');
  const scrollRef = useRef<HTMLDivElement>(null);
  const [userScrolled, setUserScrolled] = useState(false);
  const filtered =
  activeFilter === 'all' ?
  activities :
  activities.filter((a) => a.agentType === activeFilter);
  useEffect(() => {
    if (!userScrolled && scrollRef.current) {
      scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
    }
  }, [filtered, userScrolled]);
  function handleScroll() {
    if (!scrollRef.current) return;
    const { scrollTop, scrollHeight, clientHeight } = scrollRef.current;
    const atBottom = scrollHeight - scrollTop - clientHeight < 40;
    setUserScrolled(!atBottom);
  }
  return (
    <aside className="w-[320px] shrink-0 border-l border-zinc-200 bg-white flex flex-col h-full select-none">
      {/* Header */}
      <div className="flex items-center justify-between px-4 py-3 border-b border-zinc-100">
        <span className="text-sm font-semibold text-zinc-900">Activities</span>
        <span className="flex items-center gap-1.5 text-[11px] font-medium text-teal-600">
          <span className="w-2 h-2 rounded-full bg-teal-500 pulse-dot" />
          LIVE
        </span>
      </div>

      {/* Filters */}
      <div className="flex items-center gap-1 px-3 py-2 border-b border-zinc-100 overflow-x-auto">
        {filterTabs.map((tab) =>
        <button
          key={tab.key}
          onClick={() => setActiveFilter(tab.key)}
          className={`px-2.5 py-1 text-[11px] font-medium rounded-full whitespace-nowrap transition-colors duration-100 ${activeFilter === tab.key ? 'bg-zinc-900 text-white' : 'text-zinc-400 hover:text-zinc-600 hover:bg-zinc-50'}`}>
          
            {tab.label}
          </button>
        )}
      </div>

      {/* Log */}
      <div
        ref={scrollRef}
        onScroll={handleScroll}
        className="flex-1 overflow-y-auto">
        
        {filtered.map((entry, i) =>
        <div
          key={entry.id}
          className={`px-4 py-2.5 ${i < filtered.length - 1 ? 'border-b border-zinc-50' : ''}`}>
          
            <div className="flex items-center gap-2 text-[11px]">
              <span className="font-mono text-zinc-300">
                [{entry.timestamp}]
              </span>
              <span
              className={`${entry.agentType === 'coordinator' ? 'text-zinc-400' : ''}`}>
              
                {entry.emoji}
              </span>
              <span
              className={`font-semibold ${entry.agentType === 'coordinator' ? 'text-zinc-400' : 'text-zinc-700'}`}>
              
                {entry.agent}
              </span>
            </div>
            <p className="text-[12px] text-zinc-500 mt-0.5 ml-[72px]">
              {entry.action}
            </p>
          </div>
        )}
      </div>
    </aside>);

}