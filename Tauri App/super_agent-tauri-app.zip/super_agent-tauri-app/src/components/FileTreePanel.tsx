import React, { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { FolderIcon, FileTextIcon, FolderOpenIcon, RefreshCwIcon } from 'lucide-react';
import { FileNode } from '../data/mockData';
interface FileTreePanelProps {
  open: boolean;
  files: FileNode[];
  folderPath: string;
  onOpenFolder: () => void;
  onRefresh: () => void;
}
function StatusIndicator({ status }: {status?: FileNode['status'];}) {
  if (!status) return null;
  const config = {
    done: {
      label: '✔',
      className: 'text-emerald-500'
    },
    writing: {
      label: '●',
      className: 'text-teal-500 pulse-dot'
    },
    waiting: {
      label: '⏳',
      className: 'text-amber-500 text-[10px]'
    }
  };
  const c = config[status];
  return (
    <span className={`text-[11px] ml-auto shrink-0 ${c.className}`}>
      {c.label}
    </span>);

}
function TreeNode({ node, depth = 0 }: {node: FileNode;depth?: number;}) {
  const [expanded, setExpanded] = useState(false);
  const paddingLeft = 12 + depth * 16;
  if (node.type === 'folder') {
    return (
      <div>
        <button
          onClick={() => setExpanded(!expanded)}
          className="flex items-center gap-1.5 w-full py-1 hover:bg-zinc-50 transition-colors duration-75 text-left"
          style={{
            paddingLeft
          }}>
          
          {expanded ?
          <FolderOpenIcon className="w-3.5 h-3.5 text-amber-500 shrink-0" /> :

          <FolderIcon className="w-3.5 h-3.5 text-amber-500 shrink-0" />
          }
          <span className="text-[12px] font-medium text-zinc-700">
            {node.name}/
          </span>
        </button>
        {expanded &&
        node.children?.map((child, i) =>
        <TreeNode
          key={`${child.name}-${i}`}
          node={child}
          depth={depth + 1} />

        )}
      </div>);

  }
  return (
    <div
      className="flex items-center gap-1.5 py-1 pr-3 hover:bg-zinc-50 transition-colors duration-75"
      style={{
        paddingLeft
      }}>
      
      <FileTextIcon className="w-3.5 h-3.5 text-zinc-400 shrink-0" />
      <span className="text-[12px] text-zinc-600 truncate">{node.name}</span>
      <StatusIndicator status={node.status} />
    </div>);

}
function filterNodes(nodes: FileNode[], showHidden: boolean): FileNode[] {
  return nodes
    .filter(n => showHidden || !n.name.startsWith('.'))
    .map(n =>
      n.type === 'folder'
        ? { ...n, children: filterNodes(n.children ?? [], showHidden) }
        : n
    );
}

export function FileTreePanel({ open, files, folderPath, onOpenFolder, onRefresh }: FileTreePanelProps) {
  const [showHidden, setShowHidden] = useState(true);
  const visibleFiles = filterNodes(files, showHidden);

  return (
    <AnimatePresence>
      {open &&
      <motion.aside
        initial={{
          width: 0,
          opacity: 0
        }}
        animate={{
          width: 240,
          opacity: 1
        }}
        exit={{
          width: 0,
          opacity: 0
        }}
        transition={{
          duration: 0.2,
          ease: 'easeInOut'
        }}
        className="shrink-0 border-r border-zinc-200 bg-white flex flex-col h-full overflow-hidden">

          <div className="px-3 py-2.5 border-b border-zinc-100">
            <div className="flex items-center gap-1.5">
              <FolderIcon className="w-3.5 h-3.5 text-zinc-400 shrink-0" />
              <span className="text-[11px] font-mono text-zinc-500 truncate flex-1">
                {folderPath || 'No folder selected'}
              </span>
              <button
                onClick={() => setShowHidden(v => !v)}
                title={showHidden ? 'Hide hidden files' : 'Show hidden files'}
                className={`shrink-0 text-[10px] font-mono px-1.5 py-0.5 rounded transition-colors duration-100 ${showHidden ? 'bg-zinc-900 text-white' : 'text-zinc-400 hover:text-zinc-600 hover:bg-zinc-100'}`}
              >
                .*
              </button>
              <button
                onClick={onRefresh}
                title="Refresh file tree"
                className="shrink-0 p-0.5 rounded text-zinc-400 hover:text-zinc-600 hover:bg-zinc-100 transition-colors duration-100"
              >
                <RefreshCwIcon className="w-3 h-3" />
              </button>
            </div>
          </div>

          <div className="flex-1 overflow-y-auto py-1">
            {visibleFiles.map((node, i) =>
          <TreeNode key={`${node.name}-${i}`} node={node} />
          )}
          </div>

          <div className="px-3 py-2 border-t border-zinc-100">
            <button onClick={onOpenFolder} className="flex items-center gap-1.5 text-[11px] font-medium text-zinc-400 hover:text-zinc-600 transition-colors">
              <FolderIcon className="w-3.5 h-3.5" />
              Open Folder
            </button>
          </div>
        </motion.aside>
      }
    </AnimatePresence>);

}