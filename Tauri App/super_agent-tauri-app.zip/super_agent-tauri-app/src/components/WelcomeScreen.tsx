import React from 'react';
import { motion } from 'framer-motion';
interface WelcomeScreenProps {
  onSelectFolder: () => void;
}
export function WelcomeScreen({ onSelectFolder }: WelcomeScreenProps) {
  return (
    <div className="flex flex-col items-center justify-center h-screen bg-zinc-50 select-none">
      <motion.div
        initial={{
          opacity: 0,
          y: 20
        }}
        animate={{
          opacity: 1,
          y: 0
        }}
        transition={{
          duration: 0.5,
          ease: 'easeOut'
        }}
        className="flex flex-col items-center gap-10">
        
        <div className="flex items-center gap-3">
          <svg
            width="36"
            height="36"
            viewBox="0 0 36 36"
            fill="none"
            xmlns="http://www.w3.org/2000/svg">
            
            <path
              d="M18 2L32.124 10V26L18 34L3.876 26V10L18 2Z"
              fill="#0d9488"
              fillOpacity="0.1"
              stroke="#0d9488"
              strokeWidth="2" />
            
            <circle cx="18" cy="18" r="4" fill="#0d9488" />
          </svg>
          <span className="text-2xl font-semibold text-zinc-900 tracking-tight">
            Super Agent
          </span>
        </div>

        <button
          onClick={onSelectFolder}
          className="flex items-center gap-2.5 px-6 py-3 bg-zinc-900 text-white text-sm font-medium rounded-lg hover:bg-zinc-800 active:bg-zinc-950 transition-colors duration-150 focus:outline-none focus:ring-2 focus:ring-accent focus:ring-offset-2">
          
          <svg
            width="18"
            height="18"
            viewBox="0 0 24 24"
            fill="none"
            stroke="currentColor"
            strokeWidth="2"
            strokeLinecap="round"
            strokeLinejoin="round">
            
            <path d="M22 19a2 2 0 0 1-2 2H4a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h5l2 3h9a2 2 0 0 1 2 2z" />
          </svg>
          Choose folder to work with
        </button>
      </motion.div>
    </div>);

}