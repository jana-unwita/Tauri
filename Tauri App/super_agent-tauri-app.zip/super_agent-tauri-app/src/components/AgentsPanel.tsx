import React, { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { XIcon, PlusIcon, EyeIcon, EyeOffIcon, PencilIcon, Trash2Icon, CheckIcon } from 'lucide-react';
import { invoke } from '@tauri-apps/api/core';
import { Agent, LLMEntry } from '../data/mockData';

interface AgentsPanelProps {
  open: boolean;
  onClose: () => void;
  agents: Agent[];
  llms: LLMEntry[];
  projectPath: string;
  onCreateAgent: (agent: Agent) => void;
  onDeleteAgent: (id: string, source: string) => void;
  onEditAgent: (id: string, updates: { name: string; systemPrompt: string; model: string }) => void;
  onToggleVisibility: (id: string) => void;
}

const statusConfig = {
  running: { label: 'Running', color: 'bg-teal-500' },
  waiting: { label: 'Waiting', color: 'bg-amber-500' },
  done:    { label: 'Done',    color: 'bg-emerald-500' },
};

export function AgentsPanel({
  open,
  onClose,
  agents,
  llms,
  projectPath,
  onCreateAgent,
  onDeleteAgent,
  onEditAgent,
  onToggleVisibility,
}: AgentsPanelProps) {
  const defaultModel = llms[1]?.name ?? llms[0]?.name ?? '';
  const [showCreateForm, setShowCreateForm] = useState(false);
  const [newName, setNewName] = useState('');
  const [newPrompt, setNewPrompt] = useState('');
  const [newModel, setNewModel] = useState(defaultModel);

  const [editingId, setEditingId] = useState<string | null>(null);
  const [editName, setEditName] = useState('');
  const [editPrompt, setEditPrompt] = useState('');
  const [editModel, setEditModel] = useState('');

  async function handleCreate() {
    try {
      const result = await invoke<{ id: string; name: string }>('agent_create', {
        name: newName || 'New Agent',
        description: '',
        model: newModel,
        systemPrompt: newPrompt,
        projectPath,
      });
      onCreateAgent({
        id: result.id,
        name: result.name,
        emoji: '🤖',
        status: 'waiting',
        model: newModel,
        systemPrompt: newPrompt,
        tokenUsed: 0,
        tokenLimit: 128000,
        elapsed: '0s',
        liveStream: [],
        visible: true,
      });
    } catch (err) {
      console.error('Failed to create agent:', err);
      onCreateAgent({
        id: crypto.randomUUID(),
        name: newName || 'New Agent',
        emoji: '🤖',
        status: 'waiting',
        model: newModel,
        systemPrompt: newPrompt,
        tokenUsed: 0,
        tokenLimit: 128000,
        elapsed: '0s',
        liveStream: [],
        visible: true,
      });
    }
    setNewName('');
    setNewPrompt('');
    setNewModel(defaultModel);
    setShowCreateForm(false);
  }

  function startEdit(agent: Agent) {
    setEditingId(agent.id);
    setEditName(agent.name);
    setEditPrompt(agent.systemPrompt ?? '');
    setEditModel(agent.model);
  }

  function handleSaveEdit(id: string) {
    onEditAgent(id, { name: editName, systemPrompt: editPrompt, model: editModel });
    setEditingId(null);
  }

  return (
    <AnimatePresence>
      {open && (
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          transition={{ duration: 0.15 }}
          className="fixed inset-0 z-50 flex items-center justify-center bg-black/30"
          onClick={onClose}
        >
          <motion.div
            initial={{ opacity: 0, scale: 0.97, y: 8 }}
            animate={{ opacity: 1, scale: 1, y: 0 }}
            exit={{ opacity: 0, scale: 0.97, y: 8 }}
            transition={{ duration: 0.2 }}
            onClick={(e) => e.stopPropagation()}
            className="w-[520px] max-h-[80vh] bg-white rounded-xl shadow-xl border border-zinc-200 flex flex-col overflow-hidden"
          >
            {/* Header */}
            <div className="flex items-center justify-between px-5 py-4 border-b border-zinc-100 shrink-0">
              <h2 className="text-sm font-semibold text-zinc-900">Agents</h2>
              <div className="flex items-center gap-2">
                <button
                  onClick={() => { setShowCreateForm((v) => !v); setEditingId(null); }}
                  className="flex items-center gap-1.5 px-3 py-1.5 text-[12px] font-medium bg-zinc-900 text-white rounded-lg hover:bg-zinc-800 transition-colors"
                >
                  <PlusIcon className="w-3.5 h-3.5" />
                  New Agent
                </button>
                <button
                  onClick={onClose}
                  className="w-7 h-7 flex items-center justify-center rounded-md text-zinc-400 hover:text-zinc-600 hover:bg-zinc-100 transition-colors"
                >
                  <XIcon className="w-4 h-4" />
                </button>
              </div>
            </div>

            {/* Create form */}
            <AnimatePresence>
              {showCreateForm && (
                <motion.div
                  initial={{ height: 0, opacity: 0 }}
                  animate={{ height: 'auto', opacity: 1 }}
                  exit={{ height: 0, opacity: 0 }}
                  transition={{ duration: 0.2 }}
                  className="overflow-hidden shrink-0"
                >
                  <div className="px-5 py-4 border-b border-zinc-100 space-y-3 bg-zinc-50">
                    <p className="text-[11px] font-semibold uppercase tracking-wider text-zinc-400">New Agent</p>
                    <input
                      type="text"
                      value={newName}
                      onChange={(e) => setNewName(e.target.value)}
                      placeholder="Agent name"
                      className="w-full px-3 py-2 text-[13px] border border-zinc-200 rounded-lg text-zinc-700 placeholder:text-zinc-300 focus:outline-none focus:ring-2 focus:ring-teal-400 bg-white"
                    />
                    <textarea
                      value={newPrompt}
                      onChange={(e) => setNewPrompt(e.target.value)}
                      placeholder="System prompt..."
                      rows={4}
                      className="w-full px-3 py-2 text-[13px] font-mono border border-zinc-200 rounded-lg text-zinc-700 placeholder:text-zinc-300 resize-none focus:outline-none focus:ring-2 focus:ring-teal-400 bg-white"
                    />
                    <select
                      value={newModel}
                      onChange={(e) => setNewModel(e.target.value)}
                      className="w-full px-3 py-2 text-[13px] border border-zinc-200 rounded-lg bg-white text-zinc-700 focus:outline-none focus:ring-2 focus:ring-teal-400"
                    >
                      {llms.map((l) => <option key={l.id} value={l.name}>{l.label} — {l.description}</option>)}
                    </select>
                    <div className="flex justify-end gap-2">
                      <button
                        onClick={() => setShowCreateForm(false)}
                        className="px-3 py-1.5 text-[12px] font-medium text-zinc-500 hover:text-zinc-700 transition-colors"
                      >
                        Cancel
                      </button>
                      <button
                        onClick={handleCreate}
                        className="px-3 py-1.5 text-[12px] font-medium bg-teal-600 text-white rounded-lg hover:bg-teal-500 transition-colors"
                      >
                        Create
                      </button>
                    </div>
                  </div>
                </motion.div>
              )}
            </AnimatePresence>

            {/* Agent list */}
            <div className="flex-1 overflow-y-auto">
              {agents.length === 0 && (
                <p className="text-center text-[13px] text-zinc-300 py-12">No agents yet. Create one above.</p>
              )}
              {agents.map((agent) => {
                const s = statusConfig[agent.status];
                const isVisible = agent.visible !== false;
                const isEditing = editingId === agent.id;
                return (
                  <div key={agent.id} className="border-b border-zinc-100 last:border-0">
                    {/* Row */}
                    <div className="flex items-center gap-3 px-5 py-3 hover:bg-zinc-50 transition-colors">
                      <span className="text-lg leading-none shrink-0">{agent.emoji}</span>
                      <div className="flex-1 min-w-0">
                        <p className="text-[13px] font-medium text-zinc-800 truncate">{agent.name}</p>
                        <div className="flex items-center gap-1.5 mt-0.5">
                          <span className={`w-1.5 h-1.5 rounded-full ${s.color}`} />
                          <span className="text-[11px] text-zinc-400">{s.label}</span>
                          <span className="text-[11px] text-zinc-300 mx-1">·</span>
                          <span className="text-[11px] text-zinc-400 font-mono">{agent.model}</span>
                        </div>
                      </div>
                      {/* Actions */}
                      <div className="flex items-center gap-1 shrink-0">
                        <button
                          onClick={() => onToggleVisibility(agent.id)}
                          title={isVisible ? 'Hide terminal' : 'Show terminal'}
                          className={`w-7 h-7 flex items-center justify-center rounded-md transition-colors ${isVisible ? 'text-teal-500 hover:bg-teal-50' : 'text-zinc-300 hover:bg-zinc-100'}`}
                        >
                          {isVisible ? <EyeIcon className="w-3.5 h-3.5" /> : <EyeOffIcon className="w-3.5 h-3.5" />}
                        </button>
                        <button
                          onClick={() => isEditing ? setEditingId(null) : startEdit(agent)}
                          title="Edit"
                          className={`w-7 h-7 flex items-center justify-center rounded-md transition-colors ${isEditing ? 'bg-zinc-100 text-zinc-700' : 'text-zinc-400 hover:bg-zinc-100 hover:text-zinc-700'}`}
                        >
                          <PencilIcon className="w-3.5 h-3.5" />
                        </button>
                        <button
                          onClick={() => onDeleteAgent(agent.id, agent.source ?? '')}
                          title="Delete"
                          disabled={agent.source === 'predefined'}
                          className={`w-7 h-7 flex items-center justify-center rounded-md transition-colors ${agent.source === 'predefined' ? 'text-zinc-200 cursor-not-allowed' : 'text-zinc-300 hover:text-red-500 hover:bg-red-50'}`}
                        >
                          <Trash2Icon className="w-3.5 h-3.5" />
                        </button>
                      </div>
                    </div>

                    {/* Inline edit form */}
                    <AnimatePresence>
                      {isEditing && (
                        <motion.div
                          initial={{ height: 0, opacity: 0 }}
                          animate={{ height: 'auto', opacity: 1 }}
                          exit={{ height: 0, opacity: 0 }}
                          transition={{ duration: 0.18 }}
                          className="overflow-hidden"
                        >
                          <div className="px-5 pb-4 space-y-3 bg-zinc-50 border-t border-zinc-100">
                            <p className="text-[11px] font-semibold uppercase tracking-wider text-zinc-400 pt-3">Edit Agent</p>
                            <input
                              type="text"
                              value={editName}
                              onChange={(e) => setEditName(e.target.value)}
                              placeholder="Agent name"
                              className="w-full px-3 py-2 text-[13px] border border-zinc-200 rounded-lg text-zinc-700 placeholder:text-zinc-300 focus:outline-none focus:ring-2 focus:ring-teal-400 bg-white"
                            />
                            <textarea
                              value={editPrompt}
                              onChange={(e) => setEditPrompt(e.target.value)}
                              placeholder="System prompt..."
                              rows={4}
                              className="w-full px-3 py-2 text-[13px] font-mono border border-zinc-200 rounded-lg text-zinc-700 placeholder:text-zinc-300 resize-none focus:outline-none focus:ring-2 focus:ring-teal-400 bg-white"
                            />
                            <select
                              value={editModel}
                              onChange={(e) => setEditModel(e.target.value)}
                              className="w-full px-3 py-2 text-[13px] border border-zinc-200 rounded-lg bg-white text-zinc-700 focus:outline-none focus:ring-2 focus:ring-teal-400"
                            >
                              {llms.map((l) => <option key={l.id} value={l.name}>{l.label} — {l.description}</option>)}
                            </select>
                            <div className="flex justify-end gap-2">
                              <button
                                onClick={() => setEditingId(null)}
                                className="px-3 py-1.5 text-[12px] font-medium text-zinc-500 hover:text-zinc-700 transition-colors"
                              >
                                Cancel
                              </button>
                              <button
                                onClick={() => handleSaveEdit(agent.id)}
                                className="flex items-center gap-1.5 px-3 py-1.5 text-[12px] font-medium bg-teal-600 text-white rounded-lg hover:bg-teal-500 transition-colors"
                              >
                                <CheckIcon className="w-3.5 h-3.5" />
                                Save
                              </button>
                            </div>
                          </div>
                        </motion.div>
                      )}
                    </AnimatePresence>
                  </div>
                );
              })}
            </div>
          </motion.div>
        </motion.div>
      )}
    </AnimatePresence>
  );
}
