import React from 'react';
interface AutoAcceptToggleProps {
  enabled: boolean;
  onToggle: () => void;
}
export function AutoAcceptToggle({ enabled, onToggle }: AutoAcceptToggleProps) {
  return (
    <div className="flex items-center gap-2.5 select-none">
      <span className="text-[11px] font-medium text-zinc-400">Auto-accept</span>
      <button
        onClick={onToggle}
        role="switch"
        aria-checked={enabled}
        className={`relative w-9 h-5 rounded-full transition-colors duration-200 focus:outline-none focus:ring-2 focus:ring-offset-1 focus:ring-teal-400 ${enabled ? 'bg-teal-600' : 'bg-zinc-300'}`}>
        
        <span
          className={`absolute top-0.5 left-0.5 w-4 h-4 bg-white rounded-full shadow-sm transition-transform duration-200 ${enabled ? 'translate-x-4' : 'translate-x-0'}`} />
        
      </button>
    </div>);

}