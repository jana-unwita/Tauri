import React from 'react';
import { MenuIcon } from 'lucide-react';
interface TopNavBarProps {
  onToggleFileTree: () => void;
  onOpenAgents: () => void;
  onOpenSettings: () => void;
  onOpenDiff: () => void;
  fileTreeOpen: boolean;
}
export function TopNavBar({
  onToggleFileTree,
  onOpenAgents,
  onOpenSettings,
  onOpenDiff,
  fileTreeOpen
}: TopNavBarProps) {
  return (
    <header className="h-11 flex items-center justify-between px-3 border-b border-zinc-200 bg-white shrink-0 select-none">
      <div className="flex items-center gap-1">
        <button
          onClick={onToggleFileTree}
          className={`w-8 h-8 flex items-center justify-center rounded-md transition-colors duration-100 ${fileTreeOpen ? 'bg-zinc-100 text-zinc-900' : 'text-zinc-500 hover:bg-zinc-100 hover:text-zinc-700'}`}
          aria-label="Toggle file tree">
          
          <MenuIcon className="w-4 h-4" />
        </button>

        <div className="flex items-center ml-2 gap-0.5">
          {['File', 'Agents', 'Settings', 'Diff'].map((item) =>
          <button
            key={item}
            onClick={() => {
              if (item === 'File') onToggleFileTree();
              if (item === 'Agents') onOpenAgents();
              if (item === 'Settings') onOpenSettings();
              if (item === 'Diff') onOpenDiff();
            }}
            className="px-2.5 py-1 text-[13px] font-medium text-zinc-500 hover:text-zinc-900 hover:bg-zinc-50 rounded transition-colors duration-100">
            
              {item}
            </button>
          )}
        </div>
      </div>

      <div className="flex items-center gap-2 text-zinc-400">
        <svg
          width="18"
          height="18"
          viewBox="0 0 36 36"
          fill="none"
          xmlns="http://www.w3.org/2000/svg">
          
          <path
            d="M18 2L32.124 10V26L18 34L3.876 26V10L18 2Z"
            fill="#0d9488"
            fillOpacity="0.15"
            stroke="#0d9488"
            strokeWidth="1.5" />
          
          <circle cx="18" cy="18" r="3" fill="#0d9488" />
        </svg>
        <span className="text-[13px] font-semibold text-zinc-400 tracking-tight">
          Super Agent
        </span>
      </div>
    </header>);

}