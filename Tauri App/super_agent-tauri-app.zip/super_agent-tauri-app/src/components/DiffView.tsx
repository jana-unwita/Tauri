import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { XIcon, ChevronDownIcon } from 'lucide-react';
import { DiffFile, DiffLine, FileNode } from '../data/mockData';
import { FileTreePanel } from './FileTreePanel';
interface DiffViewProps {
  diffs: DiffFile[];
  onClose: () => void;
  files: FileNode[];
  folderPath: string;
  onOpenFolder: () => void;
}
function DiffLineRow({ line }: {line: DiffLine;}) {
  const bgClass = {
    add: 'bg-emerald-50',
    remove: 'bg-red-50',
    context: 'bg-white'
  }[line.type];
  const textClass = {
    add: 'text-emerald-800',
    remove: 'text-red-800',
    context: 'text-zinc-600'
  }[line.type];
  const prefix = {
    add: '+',
    remove: '-',
    context: ' '
  }[line.type];
  return (
    <div
      className={`flex font-mono text-[12px] leading-[22px] ${bgClass} border-b border-zinc-50`}>
      
      <span className="w-12 text-right pr-2 text-zinc-300 select-none shrink-0 border-r border-zinc-100">
        {line.oldLine ?? ''}
      </span>
      <span className="w-12 text-right pr-2 text-zinc-300 select-none shrink-0 border-r border-zinc-100">
        {line.newLine ?? ''}
      </span>
      <span className={`px-3 flex-1 whitespace-pre ${textClass}`}>
        <span
          className={`inline-block w-4 select-none ${line.type === 'add' ? 'text-emerald-500' : line.type === 'remove' ? 'text-red-400' : 'text-zinc-300'}`}>
          
          {prefix}
        </span>
        {line.content}
      </span>
    </div>);

}
export function DiffView({ diffs, onClose, files, folderPath, onOpenFolder }: DiffViewProps) {
  const [filterAgent, setFilterAgent] = useState<string>('all');
  const [filterOpen, setFilterOpen] = useState(false);
  const agents = Array.from(new Set(diffs.map((d) => d.agentName)));
  const filtered =
  filterAgent === 'all' ?
  diffs :
  diffs.filter((d) => d.agentName === filterAgent);
  return (
    <motion.div
      initial={{
        opacity: 0
      }}
      animate={{
        opacity: 1
      }}
      exit={{
        opacity: 0
      }}
      transition={{
        duration: 0.15
      }}
      className="absolute inset-0 bg-zinc-50 z-30 flex flex-col">
      
      {/* Header */}
      <div className="flex items-center justify-between px-5 py-3 border-b border-zinc-200 bg-white shrink-0">
        <h2 className="text-sm font-semibold text-zinc-900">Diff</h2>
        <div className="flex items-center gap-3">
          <div className="relative">
            <button
              onClick={() => setFilterOpen(!filterOpen)}
              className="flex items-center gap-1.5 px-3 py-1.5 text-[12px] font-medium text-zinc-500 border border-zinc-200 rounded-md hover:bg-zinc-50 transition-colors">
              
              Filter by Agent
              <ChevronDownIcon className="w-3.5 h-3.5" />
            </button>
            {filterOpen &&
            <div className="absolute right-0 top-full mt-1 w-48 bg-white border border-zinc-200 rounded-lg shadow-lg py-1 z-10">
                <button
                onClick={() => {
                  setFilterAgent('all');
                  setFilterOpen(false);
                }}
                className={`w-full text-left px-3 py-1.5 text-[12px] hover:bg-zinc-50 ${filterAgent === 'all' ? 'font-semibold text-zinc-900' : 'text-zinc-600'}`}>
                
                  All Agents
                </button>
                {agents.map((a) =>
              <button
                key={a}
                onClick={() => {
                  setFilterAgent(a);
                  setFilterOpen(false);
                }}
                className={`w-full text-left px-3 py-1.5 text-[12px] hover:bg-zinc-50 ${filterAgent === a ? 'font-semibold text-zinc-900' : 'text-zinc-600'}`}>
                
                    {a}
                  </button>
              )}
              </div>
            }
          </div>
          <button
            onClick={onClose}
            className="flex items-center gap-1.5 px-2.5 py-1.5 rounded-md text-red-500 hover:text-red-600 hover:bg-red-50 transition-colors text-[12px] font-medium"
            aria-label="Close diff view">

            <XIcon className="w-4 h-4" />
            Close
          </button>
        </div>
      </div>

      {/* Body */}
      <div className="flex flex-1 overflow-hidden">
        <FileTreePanel
          open={true}
          files={files}
          folderPath={folderPath}
          onOpenFolder={onOpenFolder}
        />
      <div className="flex-1 overflow-y-auto px-5 py-4 space-y-4">
        {filtered.map((file, fi) =>
        <div
          key={fi}
          className="border border-zinc-200 rounded-lg overflow-hidden bg-white">
          
            <div className="flex items-center justify-between px-4 py-2.5 bg-zinc-50 border-b border-zinc-200">
              <div className="flex items-center gap-2">
                <span className="text-[12px]">📄</span>
                <span className="text-[13px] font-mono font-medium text-zinc-800">
                  {file.fileName}
                </span>
                <span className="text-[11px] text-zinc-400 ml-2">
                  {file.agentEmoji} {file.agentName}
                </span>
              </div>
              <div className="flex items-center gap-2 text-[11px] font-mono">
                <span className="text-emerald-600">+{file.additions}</span>
                <span className="text-red-500">-{file.deletions}</span>
              </div>
            </div>
            <div>
              {file.hunks.map((line, li) =>
            <DiffLineRow key={li} line={line} />
            )}
            </div>
          </div>
        )}
      </div>
      </div>
    </motion.div>);

}