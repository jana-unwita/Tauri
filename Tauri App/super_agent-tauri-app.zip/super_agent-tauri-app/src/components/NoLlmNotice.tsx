import React from 'react';
import { motion } from 'framer-motion';
import { AlertTriangleIcon } from 'lucide-react';
interface NoLlmNoticeProps {
  onOpenSettings: () => void;
}
export function NoLlmNotice({ onOpenSettings }: NoLlmNoticeProps) {
  return (
    <div className="flex flex-col items-center justify-center h-screen bg-zinc-50 select-none">
      <motion.div
        initial={{
          opacity: 0,
          y: 16
        }}
        animate={{
          opacity: 1,
          y: 0
        }}
        transition={{
          duration: 0.4
        }}
        className="flex flex-col items-center gap-5 text-center">
        
        <div className="w-12 h-12 rounded-full bg-amber-50 flex items-center justify-center">
          <AlertTriangleIcon className="w-6 h-6 text-amber-500" />
        </div>
        <div>
          <h2 className="text-lg font-semibold text-zinc-900">
            No LLM found on your system
          </h2>
          <p className="text-sm text-zinc-500 mt-1">Add one to get started.</p>
        </div>
        <button
          onClick={onOpenSettings}
          className="px-5 py-2.5 bg-zinc-900 text-white text-sm font-medium rounded-lg hover:bg-zinc-800 active:bg-zinc-950 transition-colors duration-150 focus:outline-none focus:ring-2 focus:ring-accent focus:ring-offset-2">
          
          Open Settings
        </button>
      </motion.div>
    </div>);

}