import React, { useState, useEffect } from 'react';
import { AnimatePresence, motion } from 'framer-motion';
import { open } from '@tauri-apps/plugin-dialog';
import { invoke } from '@tauri-apps/api/core';
import { readDirectoryTree } from './utils/fileSystem';
import { WelcomeScreen } from './components/WelcomeScreen';
import { NoLlmNotice } from './components/NoLlmNotice';
import { MainCanvas } from './components/MainCanvas';
import { SettingsDialog } from './components/SettingsDialog';
import { AgentsPanel } from './components/AgentsPanel';
import {
  mockActivities,
  mockFileTree,
  mockDiffs,
  mockLLMs,
  FileNode,
  Agent } from
'./data/mockData';
type Screen = 'welcome' | 'no-llm' | 'main';
export function App() {
  const [screen, setScreen] = useState<Screen>('welcome');
  const [fileTreeOpen, setFileTreeOpen] = useState(false);
  const [diffOpen, setDiffOpen] = useState(false);
  const [settingsOpen, setSettingsOpen] = useState(false);
  const [agentsOpen, setAgentsOpen] = useState(false);
  const [autoAccept, setAutoAccept] = useState(true);
  const [folderFiles, setFolderFiles] = useState<FileNode[]>(mockFileTree);
  const [folderName, setFolderName] = useState<string>('');
  const [projectPath, setProjectPath] = useState<string>('');
  const [agents, setAgents] = useState<Agent[]>([]);
  useEffect(() => { loadAgents(''); }, []);
  function handleCreateAgent(agent: Agent) {
    setAgents((prev) => [...prev, agent]);
  }
  async function handleDeleteAgent(id: string, source: string) {
    try {
      await invoke('agent_delete', { id, source, projectPath });
    } catch (err) {
      console.error('Failed to delete agent file:', err);
    }
    setAgents((prev) => prev.filter((a) => a.id !== id));
  }
  function handleEditAgent(id: string, updates: { name: string; systemPrompt: string; model: string }) {
    setAgents((prev) => prev.map((a) => a.id === id ? { ...a, ...updates } : a));
  }
  function handleToggleVisibility(id: string) {
    setAgents((prev) => prev.map((a) => a.id === id ? { ...a, visible: a.visible === false ? true : false } : a));
  }
  async function loadAgents(path: string) {
    try {
      const infos = await invoke<Array<{
        id: string; name: string; description: string;
        model: string; system_prompt: string; source: string;
      }>>('read_agents', { projectPath: path });
      setAgents(infos.map(info => ({
        id: info.id,
        name: info.name,
        emoji: '🤖',
        status: 'waiting' as const,
        model: info.model || 'claude-sonnet-4-6',
        systemPrompt: info.system_prompt,
        tokenUsed: 0,
        tokenLimit: 200000,
        elapsed: '0s',
        liveStream: [],
        visible: true,
        source: info.source as Agent['source'],
      })));
    } catch (err) {
      console.error('Failed to load agents:', err);
    }
  }
  async function refreshFolder() {
    if (!projectPath) return;
    const nodes = await readDirectoryTree(projectPath);
    setFolderFiles(nodes);
    await loadAgents(projectPath);
  }
  async function openFolder() {
    const selected = await open({ directory: true, multiple: false });
    if (!selected || typeof selected !== 'string') return;
    // selected is the full absolute path e.g. /Users/mani/Projects/my-app
    const name = selected.split('/').pop() || selected;
    setProjectPath(selected);
    setFolderName(name);
    const nodes = await readDirectoryTree(selected);
    setFolderFiles(nodes);
    await loadAgents(selected);
    setScreen('main');
  }
  return (
    <div className="h-screen w-full overflow-hidden bg-zinc-50">
      <AnimatePresence mode="wait">
        {screen === 'welcome' &&
        <motion.div
          key="welcome"
          exit={{
            opacity: 0
          }}
          transition={{
            duration: 0.2
          }}
          className="h-full">
          
            <WelcomeScreen onSelectFolder={openFolder} />
          </motion.div>
        }

        {screen === 'no-llm' &&
        <motion.div
          key="no-llm"
          initial={{
            opacity: 0
          }}
          animate={{
            opacity: 1
          }}
          exit={{
            opacity: 0
          }}
          transition={{
            duration: 0.2
          }}
          className="h-full">
          
            <NoLlmNotice onOpenSettings={() => setSettingsOpen(true)} />
          </motion.div>
        }

        {screen === 'main' &&
        <motion.div
          key="main"
          initial={{
            opacity: 0
          }}
          animate={{
            opacity: 1
          }}
          transition={{
            duration: 0.3
          }}
          className="h-full">
          
            <MainCanvas
            agents={agents}
            activities={mockActivities}
            files={folderFiles}
            diffs={mockDiffs}
            fileTreeOpen={fileTreeOpen}
            diffOpen={diffOpen}
            autoAccept={autoAccept}
            folderName={folderName}
            cwd={projectPath}
            onOpenFolder={openFolder}
            onRefreshFiles={refreshFolder}
            onToggleFileTree={() => setFileTreeOpen((v) => !v)}
            onOpenAgents={() => setAgentsOpen(true)}
            onOpenSettings={() => setSettingsOpen(true)}
            onToggleDiff={() => setDiffOpen((v) => !v)}
            onToggleAutoAccept={() => setAutoAccept((v) => !v)} />
          
          </motion.div>
        }
      </AnimatePresence>

      {/* Global modals */}
      <SettingsDialog
        open={settingsOpen}
        onClose={() => setSettingsOpen(false)}
        llms={mockLLMs} />
      
      <AgentsPanel
        open={agentsOpen}
        onClose={() => setAgentsOpen(false)}
        agents={agents}
        llms={mockLLMs}
        projectPath={projectPath}
        onCreateAgent={handleCreateAgent}
        onDeleteAgent={handleDeleteAgent}
        onEditAgent={handleEditAgent}
        onToggleVisibility={handleToggleVisibility} />
      
    </div>);

}