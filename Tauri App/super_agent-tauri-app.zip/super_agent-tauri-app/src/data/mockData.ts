export interface Agent {
  id: string;
  name: string;
  emoji: string;
  status: 'running' | 'waiting' | 'done';
  model: string;
  tokenUsed: number;
  tokenLimit: number;
  elapsed: string;
  liveStream: string[];
  currentAction?: string;
  systemPrompt?: string;
  visible?: boolean;
  source?: 'predefined' | 'project' | 'global';
}

export interface ActivityEntry {
  id: string;
  timestamp: string;
  agent: string;
  agentType: 'coordinator' | 'planning' | 'architect' | 'developer' | 'reviewer';
  emoji: string;
  action: string;
}

export interface FileNode {
  name: string;
  type: 'file' | 'folder';
  status?: 'done' | 'writing' | 'waiting';
  children?: FileNode[];
}

export interface DiffFile {
  fileName: string;
  agentName: string;
  agentEmoji: string;
  additions: number;
  deletions: number;
  hunks: DiffLine[];
}

export interface DiffLine {
  type: 'add' | 'remove' | 'context';
  oldLine?: number;
  newLine?: number;
  content: string;
}

export interface LLMEntry {
  id: string;
  name: string;
  label: string;
  description: string;
  status: 'running' | 'idle';
}

export const mockAgents: Agent[] = [
{
  id: 'planning',
  name: 'Planning Agent',
  emoji: '📋',
  status: 'done',
  model: 'claude-sonnet-4-6',
  tokenUsed: 12400,
  tokenLimit: 200000,
  elapsed: '1m 14s',
  liveStream: [
  'Received project requirements',
  'Breaking down into subtasks...',
  'Identified 4 modules needed',
  'Created task dependency graph',
  'Sent plan to Coordinator ✔'],

  currentAction: 'Done'
},
{
  id: 'architect',
  name: 'Architect Agent',
  emoji: '🏗',
  status: 'running',
  model: 'claude-sonnet-4-6',
  tokenUsed: 40200,
  tokenLimit: 200000,
  elapsed: '4m 32s',
  liveStream: [
  'Analyzed requirements from Planning',
  'Planned module structure',
  'Created src/auth/ directory',
  'Modified config.toml',
  'Designing middleware layer...'],

  currentAction: '✏️ Writing'
},
{
  id: 'developer',
  name: 'Developer Agent',
  emoji: '💻',
  status: 'running',
  model: 'claude-sonnet-4-6',
  tokenUsed: 67800,
  tokenLimit: 200000,
  elapsed: '6m 08s',
  liveStream: [
  'Received architecture from Architect',
  'Writing handler.rs',
  'Implementing login endpoint',
  'Adding validation logic',
  'Writing middleware.rs...'],

  currentAction: '✏️ Writing'
},
{
  id: 'reviewer',
  name: 'Code Reviewer',
  emoji: '🔍',
  status: 'waiting',
  model: 'claude-sonnet-4-6',
  tokenUsed: 0,
  tokenLimit: 200000,
  elapsed: '0m 00s',
  liveStream: []
}];


export const mockActivities: ActivityEntry[] = [
{
  id: '1',
  timestamp: '10:24:11',
  agent: 'Coordinator',
  agentType: 'coordinator',
  emoji: '○',
  action: 'Received requirement from user'
},
{
  id: '2',
  timestamp: '10:24:12',
  agent: 'Coordinator',
  agentType: 'coordinator',
  emoji: '○',
  action: 'Assigned task to Planning Agent'
},
{
  id: '3',
  timestamp: '10:24:15',
  agent: 'Planning Agent',
  agentType: 'planning',
  emoji: '📋',
  action: 'Received context — breaking down requirements'
},
{
  id: '4',
  timestamp: '10:24:21',
  agent: 'Planning Agent',
  agentType: 'planning',
  emoji: '📋',
  action: 'Completed task breakdown — 4 modules identified'
},
{
  id: '5',
  timestamp: '10:24:22',
  agent: 'Coordinator',
  agentType: 'coordinator',
  emoji: '○',
  action: 'Assigned task to Architect Agent'
},
{
  id: '6',
  timestamp: '10:24:28',
  agent: 'Architect Agent',
  agentType: 'architect',
  emoji: '🏗',
  action: 'Designing system structure for auth module'
},
{
  id: '7',
  timestamp: '10:24:31',
  agent: 'Coordinator',
  agentType: 'coordinator',
  emoji: '○',
  action: 'Assigned parallel task to Developer Agent'
},
{
  id: '8',
  timestamp: '10:24:33',
  agent: 'Developer Agent',
  agentType: 'developer',
  emoji: '💻',
  action: 'Writing handler.rs — login endpoint'
},
{
  id: '9',
  timestamp: '10:24:38',
  agent: 'Architect Agent',
  agentType: 'architect',
  emoji: '🏗',
  action: 'Created src/auth/ directory structure'
},
{
  id: '10',
  timestamp: '10:24:42',
  agent: 'Developer Agent',
  agentType: 'developer',
  emoji: '💻',
  action: 'Implementing validation in middleware.rs'
}];


export const mockFileTree: FileNode[] = [
{
  name: 'src',
  type: 'folder',
  children: [
  {
    name: 'auth',
    type: 'folder',
    children: [
    { name: 'handler.rs', type: 'file', status: 'done' },
    { name: 'middleware.rs', type: 'file', status: 'writing' },
    { name: 'mod.rs', type: 'file', status: 'waiting' }]

  },
  {
    name: 'api',
    type: 'folder',
    children: [
    { name: 'routes.rs', type: 'file', status: 'done' },
    { name: 'handlers.rs', type: 'file', status: 'writing' }]

  },
  { name: 'main.rs', type: 'file', status: 'done' },
  { name: 'lib.rs', type: 'file', status: 'done' }]

},
{ name: 'Cargo.toml', type: 'file', status: 'done' },
{ name: 'config.toml', type: 'file', status: 'done' },
{ name: 'schema.sql', type: 'file', status: 'done' },
{ name: 'README.md', type: 'file', status: 'waiting' }];


export const mockDiffs: DiffFile[] = [
{
  fileName: 'src/auth/handler.rs',
  agentName: 'Architect Agent',
  agentEmoji: '🏗',
  additions: 6,
  deletions: 2,
  hunks: [
  {
    type: 'context',
    oldLine: 1,
    newLine: 1,
    content: 'use actix_web::{web, HttpResponse};'
  },
  {
    type: 'context',
    oldLine: 2,
    newLine: 2,
    content: 'use serde::{Deserialize, Serialize};'
  },
  { type: 'context', oldLine: 3, newLine: 3, content: '' },
  {
    type: 'remove',
    oldLine: 4,
    content: 'fn old_handler(req: HttpRequest) -> HttpResponse {'
  },
  {
    type: 'remove',
    oldLine: 5,
    content: '    HttpResponse::Ok().finish()'
  },
  {
    type: 'add',
    newLine: 4,
    content: 'fn handle_login(req: HttpRequest) -> HttpResponse {'
  },
  {
    type: 'add',
    newLine: 5,
    content: '    let body = req.json::<LoginRequest>().await?;'
  },
  {
    type: 'add',
    newLine: 6,
    content: '    validate_credentials(&body.username, &body.password)?;'
  },
  {
    type: 'add',
    newLine: 7,
    content: '    let token = generate_jwt(&body.username)?;'
  },
  {
    type: 'add',
    newLine: 8,
    content: '    HttpResponse::Ok().json(AuthResponse { token })'
  },
  { type: 'context', oldLine: 6, newLine: 9, content: '}' },
  { type: 'context', oldLine: 7, newLine: 10, content: '' },
  { type: 'add', newLine: 11, content: '#[derive(Deserialize)]' },
  { type: 'add', newLine: 12, content: 'struct LoginRequest {' }]

},
{
  fileName: 'config.toml',
  agentName: 'Developer Agent',
  agentEmoji: '💻',
  additions: 2,
  deletions: 1,
  hunks: [
  { type: 'remove', oldLine: 1, content: 'database = "postgres"' },
  { type: 'add', newLine: 1, content: 'database = "sqlite"' },
  { type: 'add', newLine: 2, content: 'pool_size = 5' },
  {
    type: 'context',
    oldLine: 2,
    newLine: 3,
    content: 'host = "localhost"'
  },
  { type: 'context', oldLine: 3, newLine: 4, content: 'port = 8080' }]

},
{
  fileName: 'src/api/routes.rs',
  agentName: 'Developer Agent',
  agentEmoji: '💻',
  additions: 4,
  deletions: 0,
  hunks: [
  {
    type: 'context',
    oldLine: 1,
    newLine: 1,
    content: 'use actix_web::web;'
  },
  { type: 'context', oldLine: 2, newLine: 2, content: '' },
  {
    type: 'context',
    oldLine: 3,
    newLine: 3,
    content: 'pub fn configure(cfg: &mut web::ServiceConfig) {'
  },
  { type: 'add', newLine: 4, content: '    cfg.service(' },
  {
    type: 'add',
    newLine: 5,
    content:
    '        web::resource("/login").route(web::post().to(handle_login))'
  },
  { type: 'add', newLine: 6, content: '    );' },
  { type: 'add', newLine: 7, content: '    cfg.service(' },
  { type: 'context', oldLine: 4, newLine: 8, content: '}' }]

}];


export const mockLLMs: LLMEntry[] = [
  { id: '1', name: 'claude-opus-4-6', label: 'Opus 4.6', description: '1M context · Most capable for complex work', status: 'running' },
  { id: '2', name: 'claude-sonnet-4-6', label: 'Sonnet 4.6', description: 'Best for everyday tasks', status: 'running' },
  { id: '3', name: 'claude-haiku-4-5-20251001', label: 'Haiku 4.5', description: 'Fastest for quick answers', status: 'running' },
];