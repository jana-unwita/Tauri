import { invoke } from '@tauri-apps/api/core';
import { FileNode } from '../data/mockData';

function sortNodes(nodes: FileNode[]): void {
  nodes.sort((a, b) => {
    if (a.type !== b.type) return a.type === 'folder' ? -1 : 1;
    return a.name.localeCompare(b.name);
  });
  for (const node of nodes) {
    if (node.children) sortNodes(node.children);
  }
}

export async function readDirectoryTree(dirPath: string): Promise<FileNode[]> {
  return invoke<FileNode[]>('read_dir_tree', { path: dirPath });
}

export function buildFileTreeFromFileList(fileList: FileList): { name: string; nodes: FileNode[] } {
  const files = Array.from(fileList);
  if (files.length === 0) return { name: '', nodes: [] };

  // webkitRelativePath format: "rootFolder/src/index.ts"
  const rootName = files[0].webkitRelativePath.split('/')[0];
  const root: FileNode = { name: rootName, type: 'folder', children: [] };

  for (const file of files) {
    const parts = file.webkitRelativePath.split('/');
    // parts[0] is the root folder — skip it
    let current = root;
    for (let i = 1; i < parts.length; i++) {
      const part = parts[i];
      const isLast = i === parts.length - 1;
      if (isLast) {
        current.children!.push({ name: part, type: 'file' });
      } else {
        let folder = current.children!.find((n) => n.name === part && n.type === 'folder');
        if (!folder) {
          folder = { name: part, type: 'folder', children: [] };
          current.children!.push(folder);
        }
        current = folder;
      }
    }
  }

  sortNodes(root.children!);
  return { name: rootName, nodes: root.children! };
}
