// vite.config.ts
import { defineConfig } from 'vite'
import react from '@vitejs/plugin-react'

export default defineConfig({
  plugins: [react()],

  // Prevent Vite from obscuring Rust error messages
  clearScreen: false,

  server: {
    port: 5000,
    strictPort: true,   // Fail if port is taken (Tauri expects a fixed port)
    watch: {
      // Watch src-tauri for rebuild triggers
      ignored: ['**/src-tauri/**'],
    },
  },

  build: {
    // Tauri supports ES2021+ on all supported OS versions
    target: ['es2021', 'chrome105', 'safari13'],
    minify: !process.env.TAURI_DEBUG ? 'esbuild' : false,
    sourcemap: !!process.env.TAURI_DEBUG,
  },
})